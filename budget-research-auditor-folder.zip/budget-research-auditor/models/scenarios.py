"""Scenario engine — planned for a later build stage.

Low/base/high scenario definitions derived only from the approved CP0 scope.
"""


def run(*args, **kwargs):
    raise NotImplementedError("Scenario engine is not implemented in this build stage (CP0-CP1 only).")
