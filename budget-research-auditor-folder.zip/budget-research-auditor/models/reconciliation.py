"""Reconciliation — planned for a later build stage.

Independent recomputation of model totals and report/model consistency checks.
"""


def run(*args, **kwargs):
    raise NotImplementedError("Reconciliation is not implemented in this build stage (CP0-CP1 only).")
