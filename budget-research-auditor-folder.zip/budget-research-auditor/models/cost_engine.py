"""Cost engine — planned for a later build stage.

Pure-Python recalculation of cost items (pack-size/MOQ rounding, failure-rate uplift, unit normalisation) used to cross-check Excel formulas.
"""


def run(*args, **kwargs):
    raise NotImplementedError("Cost engine is not implemented in this build stage (CP0-CP1 only).")
