"""Shared Excel helpers: consistent, readable workbooks for non-technical users."""
from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HEADER_FILL = PatternFill("solid", fgColor="1F3864")
HEADER_FONT = Font(color="FFFFFF", bold=True)
SAMPLE_FILL = PatternFill("solid", fgColor="FCE4D6")


def write_sheet(ws, rows: list[dict], columns: list[str] | None = None) -> None:
    columns = columns or (list(rows[0].keys()) if rows else ["(no rows)"])
    ws.append(columns)
    for c in ws[1]:
        c.fill, c.font = HEADER_FILL, HEADER_FONT
        c.alignment = Alignment(wrap_text=True, vertical="top")
    for r in rows:
        ws.append([_cell(r.get(c)) for c in columns])
    for i, col in enumerate(columns, start=1):
        width = max([len(str(col))] + [len(str(_cell(r.get(col)) or "")) for r in rows[:200]])
        ws.column_dimensions[get_column_letter(i)].width = min(max(10, width + 2), 60)
    for row in ws.iter_rows(min_row=2):
        for c in row:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.freeze_panes = "A2"
    if rows:
        ws.auto_filter.ref = ws.dimensions


def _cell(v):
    if isinstance(v, (list, tuple)):
        return "; ".join(str(x) for x in v)
    if isinstance(v, dict):
        return "; ".join(f"{k}={x}" for k, x in v.items())
    return v


def build_workbook(path: Path, readme_lines: list[str], sheets: dict[str, tuple[list[dict], list[str] | None]],
                   sample: bool = False) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "README"
    if sample:
        ws.append(["SAMPLE / MOCK DATA - not research evidence. Do not use for decisions."])
        ws["A1"].fill, ws["A1"].font = SAMPLE_FILL, Font(bold=True, color="C00000")
    for line in readme_lines:
        ws.append([line])
    ws.column_dimensions["A"].width = 120
    for name, (rows, cols) in sheets.items():
        write_sheet(wb.create_sheet(name), rows, cols)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path
