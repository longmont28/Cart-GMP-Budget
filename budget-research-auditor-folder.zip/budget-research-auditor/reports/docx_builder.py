"""CP9 DOCX report — planned for a later build stage.

Generate the ~10,000-word report strictly from approved CP0-CP8 data; refuses to run unless CP0-CP8 are APPROVED.
"""


def run(*args, **kwargs):
    raise NotImplementedError("CP9 DOCX report is not implemented in this build stage (CP0-CP1 only).")
