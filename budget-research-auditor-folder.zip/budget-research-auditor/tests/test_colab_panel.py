"""The Colab panel: always targets the next unapproved checkpoint; buttons obey the gates."""
from app.colab_panel import Panel


def test_panel_walks_cp0_to_cp1(ws):
    p = Panel(ws)
    assert p.cp == "CP0"
    p.b_run.click()
    assert p.m.get("CP0").status == "IN_PROGRESS"
    p.name.value = "Andy Yu"
    p.b_approve.click()                      # not ticked -> nothing happens
    assert p.m.get("CP0").status == "IN_PROGRESS"
    p.ack.value = True
    p.b_approve.click()
    assert p.m.get("CP0").status == "APPROVED"
    assert p.cp == "CP1"                     # panel moves on by itself
    assert p.ack.value is False              # tick resets for the next checkpoint


def test_panel_rejects_numeric_or_agent_names(ws):
    p = Panel(ws)
    p.b_run.click()
    for bad in ("123456", "claude", ""):
        p.name.value = bad
        p.ack.value = True
        p.b_approve.click()
        assert p.m.get("CP0").status == "IN_PROGRESS"


def test_panel_settings_save_invalidates_and_bad_yaml_rejected(ws):
    p = Panel(ws)
    p.b_run.click(); p.name.value = "Andy Yu"; p.ack.value = True; p.b_approve.click()
    p.yaml_box.value = "this: [is broken"
    p.b_save.click()
    assert "格式错误" in p.yaml_msg.value
    assert p.m.get("CP0").status == "APPROVED"
    p._load_yaml()
    p.yaml_box.value = p.yaml_box.value.replace("project_duration_months: 36", "project_duration_months: 48")
    p.b_save.click()
    assert p.m.get("CP0").status == "BLOCKED" and p.cp == "CP0"


def test_panel_revision_flow(ws):
    p = Panel(ws)
    p.b_run.click()
    p.name.value = "Andy Yu"
    p.feedback.value = "Use 20 doses per year"
    p.b_revise.click()
    rec = p.m.get("CP0")
    assert rec.status == "IN_PROGRESS" and rec.feedback[-1]["text"] == "Use 20 doses per year"
    p.ack.value = True; p.b_approve.click()
    assert p.m.get("CP0").status == "IN_PROGRESS"     # must re-run first
    p.b_run.click(); p.ack.value = True; p.b_approve.click()
    assert p.m.get("CP0").status == "APPROVED"
