"""Validator framework and evidence registry tests (MOCK data)."""
from checkpoints import validators as V
from checkpoints.evidence import EvidenceRegistry
from agents.infrastructure import Prober, classify_license, probe_tool


def test_crashing_test_is_not_executed_and_blocks():
    rep = V.ValidationReport("CPX")
    V.Checker(rep).run("X-01", "boom", V.CRITICAL, lambda: 1 / 0)
    assert rep.tests[0].status == V.NOT_EXECUTED
    assert not rep.passed and rep.blocking_issues


def test_empty_report_never_passes():
    assert V.ValidationReport("CPX").passed is False


def test_warning_does_not_block_but_critical_failure_does():
    rep = V.ValidationReport("CPX")
    ck = V.Checker(rep)
    ck.run("A", "warn", V.MINOR, lambda: (False, "m", ["i"]), fail_status=V.WARNING)
    assert rep.passed
    ck.run("B", "crit", V.CRITICAL, lambda: (False, "m", ["fix me"]))
    assert not rep.passed and rep.blocking_issues == ["fix me"]


def test_evidence_ids_are_stable_and_changes_supersede(tmp_path):
    ev = EvidenceRegistry(tmp_path / "r.json")
    a = ev.upsert_by_key("assumptions", "k", {"value": 1}, "MOCK", "test")
    b = ev.upsert_by_key("assumptions", "k", {"value": 1}, "MOCK", "test")
    assert a["id"] == b["id"] == "ASSUMP-0001"
    c = ev.upsert_by_key("assumptions", "k", {"value": 2}, "MOCK", "test")
    assert c["id"] == "ASSUMP-0002" and c["supersedes"] == "ASSUMP-0001"
    old = [r for r in ev.all("assumptions", include_superseded=True) if r["id"] == "ASSUMP-0001"][0]
    assert old["status"] == "SUPERSEDED"
    s = ev.record_source_access("https://example.org/x", "x", False, "HTTP 403", "MOCK", "test")
    assert s["id"] == "SRC-0001" and s["access_status"] == "ACCESS_FAILED"


def test_evidence_rejects_unknown_origin(tmp_path):
    import pytest
    with pytest.raises(ValueError):
        EvidenceRegistry(tmp_path / "r.json").add("sources", {}, "MADE_UP", "test")


def test_licence_classification():
    assert classify_license("MIT") == "PERMISSIVE"
    assert classify_license("AGPL-3.0-only") == "COPYLEFT"
    assert classify_license("Apache-2.0") == "PERMISSIVE"
    assert classify_license(None) == "UNKNOWN"


def test_offline_probe_never_guesses(monkeypatch):
    pr = Prober(offline=True)
    row = probe_tool({"name": "nonexistent-pkg-xyz", "kind": "python_package", "dist": "nonexistent-pkg-xyz"}, pr)
    assert row["status"] == "NOT_VERIFIED" and not row["installed_by_tool"]
    assert any(l["result"] == "SKIPPED" for l in pr.log)
    host = probe_tool({"name": "web", "kind": "host_tool", "declared_status": "DECLARED_UNAVAILABLE",
                       "declared_note": "disabled"}, pr)
    assert host["status"] == "DECLARED_UNAVAILABLE" and "Declared" in host["verification_method"]
