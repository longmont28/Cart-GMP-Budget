"""Gate, state and invalidation tests (MOCK data in temporary workspaces)."""
import json
import sqlite3

import pytest

from checkpoints.manager import ORDER, CheckpointManager, GateError
from checkpoints.state import APPROVED, BLOCKED, IN_PROGRESS, NOT_STARTED
from tests.conftest import edit_project


def approve(m, cp, who="Test Analyst"):
    return m.approve(cp, who, f"APPROVE {cp}")


def test_initial_state_all_not_started(ws):
    m = CheckpointManager(ws)
    assert [m.get(cp).status for cp in ORDER] == [NOT_STARTED] * 10


def test_cp0_runs_and_waits_for_user(ws):
    m = CheckpointManager(ws)
    rec = m.run("CP0")
    assert rec.status == IN_PROGRESS            # validated, awaiting approval — never auto-approved
    assert rec.validation["passed"] is True
    sample = [t for t in rec.validation["tests"] if t["test_id"] == "CP0-11"][0]
    assert sample["status"] == "WARNING"        # sample data is flagged
    assert (ws / "outputs" / "CP0" / "Project_Scope.json").exists()
    assert rec.input_hashes and rec.output_hashes and rec.versions["python"]


def test_cp1_cannot_start_before_cp0_approved(ws):
    m = CheckpointManager(ws)
    m.run("CP0")
    with pytest.raises(GateError, match="CP0 is IN_PROGRESS"):
        m.run("CP1")
    assert m.get("CP1").status == NOT_STARTED
    assert any(e["action"] == "RUN_REFUSED" for e in m.store.events("CP1"))


@pytest.mark.parametrize("who,phrase", [("claude", "APPROVE CP0"), ("Agent", "APPROVE CP0"),
                                        ("", "APPROVE CP0"), ("Test Analyst", "yes"),
                                        ("Test Analyst", "APPROVE CP1"), ("Test Analyst", "approve cp0")])
def test_approval_requires_human_and_exact_phrase(ws, who, phrase):
    m = CheckpointManager(ws)
    m.run("CP0")
    with pytest.raises(GateError):
        m.approve("CP0", who, phrase)
    assert m.get("CP0").status == IN_PROGRESS
    assert m.store.events("CP0")[-1]["action"] == "APPROVAL_REFUSED"


def test_invalid_scope_is_blocked_with_actionable_issues(ws):
    edit_project(ws, annual_production_volume__value=-5, currency__reporting="TBD",
                 budget_boundaries__out_of_scope=[])
    m = CheckpointManager(ws)
    rec = m.run("CP0")
    assert rec.status == BLOCKED
    issues = " ".join(rec.validation["blocking_issues"])
    assert "positive number" in issues and "ISO 4217" in issues and "excluded" in issues
    with pytest.raises(GateError):
        approve(m, "CP0")


def test_blocked_checkpoint_cannot_be_approved_even_with_phrase(ws):
    edit_project(ws, scenarios__base__annual_volume=99)
    m = CheckpointManager(ws)
    assert m.run("CP0").status == BLOCKED
    with pytest.raises(GateError, match="only a validated IN_PROGRESS"):
        approve(m, "CP0")


def test_full_cp0_cp1_flow_manual_documents(ws):
    edit_project(ws, research_mode="manual_documents")
    m = CheckpointManager(ws)
    m.run("CP0")
    approve(m, "CP0")
    rec = m.run("CP1")
    assert rec.validation["passed"], rec.validation["blocking_issues"]
    assert rec.status == IN_PROGRESS
    approve(m, "CP1")
    assert m.get("CP1").status == APPROVED
    with pytest.raises(NotImplementedError):     # CP2 not built in this stage
        m.run("CP2")


def test_cp1_blocks_when_web_research_unavailable(ws):
    m = CheckpointManager(ws)                    # sample config: research_mode=web, web search declared unavailable
    m.run("CP0")
    approve(m, "CP0")
    rec = m.run("CP1")
    assert rec.status == BLOCKED
    assert any("web_search" in i for i in rec.validation["blocking_issues"])


def test_upstream_change_invalidates_downstream_and_keeps_history(ws):
    edit_project(ws, research_mode="manual_documents")
    m = CheckpointManager(ws)
    m.run("CP0"); approve(m, "CP0")
    m.run("CP1"); approve(m, "CP1")
    old_snapshots = m.store.runs("CP0")
    edit_project(ws, project_duration_months=48)
    flagged = m.refresh()
    assert flagged[:2] == ["CP0", "CP1"]
    for cp in ("CP0", "CP1"):
        r = m.get(cp)
        assert r.status == BLOCKED and r.revalidation_reason and r.approval is None
        assert r.approval_history[-1]["revoked_reason"]
    with pytest.raises(GateError):
        m.run("CP1")                             # upstream not approved any more
    m.run("CP0")
    assert len(m.store.runs("CP0")) == len(old_snapshots) + 1
    first_snap = old_snapshots[0]["snapshot_dir"]
    assert json.loads(open(f"{first_snap}/Project_Scope.json").read())["project_duration_months"] == 36
    approve(m, "CP0")
    assert m.run("CP1").validation["passed"]


def test_manual_edit_of_deliverable_is_detected(ws):
    m = CheckpointManager(ws)
    m.run("CP0"); approve(m, "CP0")
    p = ws / "outputs" / "CP0" / "Project_Scope.json"
    d = json.loads(p.read_text()); d["project_duration_months"] = 1; p.write_text(json.dumps(d))
    assert "CP0" in m.refresh()
    assert m.get("CP0").status == BLOCKED
    with pytest.raises(GateError, match="changed since the last run"):
        m.validate("CP0")


def test_rerun_with_identical_output_keeps_approval(ws):
    m = CheckpointManager(ws)
    m.run("CP0"); approve(m, "CP0")
    rec = m.run("CP0")                           # same inputs -> byte-identical deliverable
    assert rec.status == APPROVED and rec.approval["user"] == "Test Analyst"
    assert m.store.events("CP0")[-1]["action"] == "RUN_NO_CHANGE"
    assert len(m.store.runs("CP0")) == 2         # the re-run is still archived


def test_request_revision_returns_to_in_progress_and_requires_revalidation(ws):
    edit_project(ws, research_mode="manual_documents")
    m = CheckpointManager(ws)
    m.run("CP0"); approve(m, "CP0")
    m.run("CP1")
    rec = m.request_revision("CP0", "Test Analyst", "Volume should be 20 doses")
    assert rec.status == IN_PROGRESS and rec.feedback[-1]["text"].startswith("Volume")
    assert m.get("CP1").status == BLOCKED and m.get("CP1").revalidation_reason
    with pytest.raises(GateError, match="no passing validation"):
        approve(m, "CP0")
    with pytest.raises(GateError):
        m.request_revision("CP0", "x", "   ")


def test_audit_log_is_append_only_and_exportable(ws):
    m = CheckpointManager(ws)
    m.run("CP0"); approve(m, "CP0")
    con = sqlite3.connect(ws / "data" / "checkpoint_state" / "state.sqlite")
    with pytest.raises(sqlite3.DatabaseError, match="append-only"):
        con.execute("UPDATE events SET actor='x'")
    with pytest.raises(sqlite3.DatabaseError, match="append-only"):
        con.execute("DELETE FROM events")
    con.close()
    j, md = m.export_audit_log()
    data = json.loads(j.read_text())
    assert any(e["action"] == "APPROVED" for e in data["events"])
    assert "CP0 Project Scope | APPROVED" in md.read_text()


def test_state_survives_restart(ws):
    m = CheckpointManager(ws)
    m.run("CP0"); approve(m, "CP0")
    m2 = CheckpointManager(ws)                   # simulate closing and reopening the tool
    assert m2.get("CP0").status == APPROVED
    assert m2.get("CP0").approval["user"] == "Test Analyst"


def test_invalid_status_rejected_by_database(ws):
    m = CheckpointManager(ws)
    rec = m.get("CP0"); rec.status = "SKIPPED"
    with pytest.raises(ValueError):
        m.store.save(rec)


def test_cli_has_no_skip_command():
    from app import cli
    import argparse
    with pytest.raises(SystemExit):
        cli.main(["skip-all"])
    src = open(cli.__file__).read().lower()
    assert "approve-all" not in src and "skip_all" not in src
