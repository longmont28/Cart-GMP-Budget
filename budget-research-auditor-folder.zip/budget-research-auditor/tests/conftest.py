import shutil
import sys
from pathlib import Path

import pytest
import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


@pytest.fixture
def ws(tmp_path, monkeypatch):
    """Isolated workspace with copies of the sample config. Network probes off.
    All data produced here is MOCK test data."""
    monkeypatch.setenv("BRA_OFFLINE", "1")
    shutil.copytree(ROOT / "config", tmp_path / "config")
    return tmp_path


def edit_project(ws: Path, **changes):
    p = ws / "config" / "project.yaml"
    cfg = yaml.safe_load(p.read_text())
    for dotted, val in changes.items():
        cur = cfg
        keys = dotted.split("__")
        for k in keys[:-1]:
            cur = cur[k]
        cur[keys[-1]] = val
    p.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True))
