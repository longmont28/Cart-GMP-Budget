"""Smoke test: the Streamlit dashboard renders and its approve form enforces the gate."""
import os
from pathlib import Path

from streamlit.testing.v1 import AppTest

from checkpoints.manager import CheckpointManager

APP = str(Path(__file__).resolve().parents[1] / "app" / "dashboard.py")


def test_dashboard_renders_and_refuses_agent_approval(ws, monkeypatch):
    monkeypatch.setenv("BRA_ROOT", str(ws))
    CheckpointManager(ws).run("CP0")
    at = AppTest.from_file(APP, default_timeout=30).run()
    assert not at.exception
    assert any("SAMPLE PROJECT" in e.value for e in at.error)
    at.text_input[0].input("claude")
    at.text_input[1].input("APPROVE CP0")
    at.button[-2].click().run()          # Approve form submit
    assert any("named human" in e.value for e in at.error)
    assert CheckpointManager(ws).get("CP0").status == "IN_PROGRESS"
