"""Validation framework and checkpoint validators.

Rules:
* A test is only PASSED if it actually executed and its condition held.
* Tests that could not run are NOT_EXECUTED and count against the gate if
  they are required.
* A checkpoint passes validation only when no CRITICAL or MAJOR test failed
  and no required test is NOT_EXECUTED.
"""
from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable

from .state import now_iso, sha256_file

PASSED, FAILED, WARNING, NOT_EXECUTED = "PASSED", "FAILED", "WARNING", "NOT_EXECUTED"
CRITICAL, MAJOR, MINOR, INFO = "CRITICAL", "MAJOR", "MINOR", "INFO"
BLOCKING_SEVERITIES = (CRITICAL, MAJOR)

# ISO 4217 codes most likely to be used; extend as needed.
ISO_4217 = {
    "SEK", "EUR", "USD", "GBP", "NOK", "DKK", "CHF", "JPY", "CNY", "CAD", "AUD",
    "INR", "KRW", "SGD", "HKD", "PLN", "CZK", "BRL", "MXN", "ZAR", "NZD", "ISK",
}
PLACEHOLDERS = {"", "tbd", "todo", "n/a", "na", "unknown", "?", "xxx", "none"}
FACILITY_MODELS = {"in_house", "outsourced", "hybrid"}
CONFIDENCE_LEVELS = {"LOW", "MEDIUM", "HIGH"}


@dataclass
class TestResult:
    test_id: str
    name: str
    status: str
    severity: str
    message: str
    issues: list[str] = field(default_factory=list)   # actionable items
    required: bool = True

    @property
    def blocking(self) -> bool:
        if self.status == FAILED and self.severity in BLOCKING_SEVERITIES:
            return True
        return self.status == NOT_EXECUTED and self.required


@dataclass
class ValidationReport:
    checkpoint_id: str
    tests: list[TestResult] = field(default_factory=list)
    ran_at: str = field(default_factory=now_iso)
    validated_output_hashes: dict = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        return bool(self.tests) and not any(t.blocking for t in self.tests)

    @property
    def blocking_issues(self) -> list[str]:
        out = []
        for t in self.tests:
            if t.blocking:
                out.extend(t.issues or [f"{t.test_id} {t.name}: {t.message}"])
        return out

    def summary(self) -> dict:
        counts: dict[str, int] = {}
        for t in self.tests:
            counts[t.status] = counts.get(t.status, 0) + 1
        return counts

    def to_dict(self) -> dict:
        return {
            "checkpoint_id": self.checkpoint_id, "ran_at": self.ran_at,
            "passed": self.passed, "summary": self.summary(),
            "blocking_issues": self.blocking_issues,
            "validated_output_hashes": self.validated_output_hashes,
            "tests": [asdict(t) | {"blocking": t.blocking} for t in self.tests],
        }


class Checker:
    """Small helper so each test is written as one guarded function."""

    def __init__(self, report: ValidationReport):
        self.report = report

    def run(self, test_id: str, name: str, severity: str, fn: Callable[[], tuple[bool, str, list[str]]],
            required: bool = True, fail_status: str = FAILED) -> TestResult:
        try:
            ok, msg, issues = fn()
            status = PASSED if ok else fail_status
        except Exception as exc:  # the test itself could not execute
            status, msg, issues = NOT_EXECUTED, f"test could not execute: {exc!r}", [
                f"{test_id} {name}: test crashed ({exc!r}); fix the input and re-run validation"]
        res = TestResult(test_id, name, status, severity, msg, issues, required)
        self.report.tests.append(res)
        return res


def _blank(v: Any) -> bool:
    return v is None or (isinstance(v, str) and v.strip().lower() in PLACEHOLDERS)


def _get(d: dict, dotted: str) -> Any:
    cur: Any = d
    for part in dotted.split("."):
        if not isinstance(cur, dict) or part not in cur:
            return None
        cur = cur[part]
    return cur


# ---------------------------------------------------------------------------
# Common
# ---------------------------------------------------------------------------
def check_outputs_exist(ck: Checker, paths: list[Path]) -> None:
    def fn():
        missing = [str(p) for p in paths if not Path(p).exists()]
        return (not missing, "all deliverables present" if not missing else f"missing: {missing}",
                [f"Deliverable not generated: {m}. Re-run the checkpoint." for m in missing])
    ck.run("GEN-01", "Deliverables exist", CRITICAL, fn)


# ---------------------------------------------------------------------------
# CP0 — Project scope
# ---------------------------------------------------------------------------
CP0_REQUIRED_FIELDS = [
    ("project.name", "Project name"),
    ("product.name", "Product name"),
    ("product.description", "Product description"),
    ("product.category", "Product category"),
    ("geography.development", "Development geography"),
    ("geography.manufacturing", "Manufacturing geography"),
    ("development_stage", "Development stage"),
    ("annual_production_volume.value", "Annual production volume"),
    ("annual_production_volume.unit", "Production volume unit"),
    ("project_duration_months", "Project duration (months)"),
    ("currency.reporting", "Reporting currency"),
    ("facility.model", "Facility model"),
    ("facility.description", "Facility description"),
]


def validate_cp0(scope_path: Path) -> ValidationReport:
    rep = ValidationReport("CP0")
    ck = Checker(rep)
    check_outputs_exist(ck, [scope_path])
    if not scope_path.exists():
        return rep
    scope = json.loads(scope_path.read_text())

    def required_fields():
        bad = [label for key, label in CP0_REQUIRED_FIELDS if _blank(_get(scope, key))]
        return (not bad, f"{len(CP0_REQUIRED_FIELDS) - len(bad)}/{len(CP0_REQUIRED_FIELDS)} required fields filled",
                [f"Fill in '{b}' in config/project.yaml (placeholder or empty)." for b in bad])
    ck.run("CP0-01", "Required scope fields present", CRITICAL, required_fields)

    def numeric_ranges():
        issues = []
        vol = _get(scope, "annual_production_volume.value")
        dur = _get(scope, "project_duration_months")
        if not isinstance(vol, (int, float)) or vol <= 0:
            issues.append(f"Annual production volume must be a positive number (got {vol!r}).")
        if not isinstance(dur, (int, float)) or not (1 <= dur <= 240):
            issues.append(f"Project duration must be 1–240 months (got {dur!r}).")
        return not issues, "volume and duration in range" if not issues else "out-of-range values", issues
    ck.run("CP0-02", "Volume and duration plausible", CRITICAL, numeric_ranges)

    def currency():
        cur = str(_get(scope, "currency.reporting") or "").upper()
        issues = [] if cur in ISO_4217 else [f"Reporting currency '{cur}' is not a recognised ISO 4217 code."]
        fx = _get(scope, "currency.fx_policy")
        if _blank(fx):
            issues.append("State an FX policy (rate source and date) in currency.fx_policy.")
        return not issues, f"currency {cur}", issues
    ck.run("CP0-03", "Currency and FX policy defined", CRITICAL, currency)

    def facility():
        m = _get(scope, "facility.model")
        ok = m in FACILITY_MODELS
        return ok, f"facility model {m}", [] if ok else [f"facility.model must be one of {sorted(FACILITY_MODELS)}."]
    ck.run("CP0-04", "Facility model valid", MAJOR, facility)

    def boundaries():
        ins = _get(scope, "budget_boundaries.in_scope") or []
        outs = _get(scope, "budget_boundaries.out_of_scope") or []
        issues = []
        if not ins:
            issues.append("List at least one in-scope cost area in budget_boundaries.in_scope.")
        if not outs:
            issues.append("List what is explicitly excluded in budget_boundaries.out_of_scope.")
        overlap = {s.strip().lower() for s in ins} & {s.strip().lower() for s in outs}
        if overlap:
            issues.append(f"Items both in and out of scope: {sorted(overlap)}.")
        return not issues, f"{len(ins)} in scope, {len(outs)} out of scope", issues
    ck.run("CP0-05", "Budget boundaries defined, no overlap", CRITICAL, boundaries)

    assumptions = scope.get("assumptions_register", [])

    def assumption_fields():
        issues = []
        if not assumptions:
            issues.append("Assumptions register is empty; add at least the key planning assumptions.")
        for a in assumptions:
            for f_ in ("assumption_id", "description", "value", "unit", "basis", "confidence", "owner"):
                if _blank(a.get(f_)) and a.get(f_) != 0:
                    issues.append(f"{a.get('assumption_id', a.get('key'))}: missing '{f_}'.")
            if a.get("confidence") not in CONFIDENCE_LEVELS:
                issues.append(f"{a.get('assumption_id')}: confidence must be LOW/MEDIUM/HIGH.")
            if a.get("assumption_id") and not re.fullmatch(r"ASSUMP-\d{4}", a["assumption_id"]):
                issues.append(f"{a['assumption_id']}: ID must match ASSUMP-0000 format.")
        return not issues, f"{len(assumptions)} assumptions checked", issues
    ck.run("CP0-06", "Assumptions register complete", MAJOR, assumption_fields)

    def assumption_dupes():
        keys = [a.get("key") for a in assumptions]
        ids = [a.get("assumption_id") for a in assumptions]
        dk = sorted({k for k in keys if keys.count(k) > 1})
        di = sorted({i for i in ids if ids.count(i) > 1})
        issues = [f"Duplicate assumption key: {k}" for k in dk] + [f"Duplicate assumption ID: {i}" for i in di]
        return not issues, "no duplicates" if not issues else "duplicates found", issues
    ck.run("CP0-07", "No duplicate assumptions", CRITICAL, assumption_dupes)

    def exposure():
        issues, missing = [], []
        for a in assumptions:
            lo, hi = a.get("exposure_low"), a.get("exposure_high")
            if lo is None or hi is None:
                missing.append(a.get("assumption_id"))
                continue
            if not isinstance(lo, (int, float)) or not isinstance(hi, (int, float)) or lo > hi:
                issues.append(f"{a.get('assumption_id')}: exposure_low must be ≤ exposure_high (numbers).")
        if issues:
            return False, "invalid exposure ranges", issues
        if missing:
            return False, f"{len(missing)} assumptions without exposure estimate", [
                f"{m}: add exposure_low/exposure_high so financial exposure can be estimated." for m in missing]
        return True, "all assumptions carry an exposure range", []
    ck.run("CP0-08", "Exposure ranges valid", MINOR, exposure, fail_status=WARNING)

    def scenarios():
        sc = scope.get("scenarios") or {}
        vol = _get(scope, "annual_production_volume.value")
        try:
            lo, base, hi = sc["low"]["annual_volume"], sc["base"]["annual_volume"], sc["high"]["annual_volume"]
        except (KeyError, TypeError):
            return False, "scenarios incomplete", ["Define scenarios.low/base/high.annual_volume."]
        issues = []
        if not (0 < lo <= base <= hi):
            issues.append(f"Scenario volumes must satisfy 0 < low ≤ base ≤ high (got {lo}, {base}, {hi}).")
        if base != vol:
            issues.append(f"Base scenario volume ({base}) must equal annual_production_volume ({vol}).")
        return not issues, f"low/base/high = {lo}/{base}/{hi}", issues
    ck.run("CP0-09", "Scenario volumes consistent with scope", CRITICAL, scenarios)

    def research_mode():
        mode = scope.get("research_mode")
        ok = mode in ("web", "manual_documents")
        return ok, f"research_mode={mode}", [] if ok else ["research_mode must be 'web' or 'manual_documents'."]
    ck.run("CP0-10", "Research mode declared", MAJOR, research_mode)

    def origin():
        o = scope.get("data_origin")
        if o == "SAMPLE":
            return False, "SAMPLE project — values are illustrative, not research evidence", [
                "This scope is SAMPLE data. Replace config/project.yaml with the real project before relying on outputs."]
        return o == "REAL", f"data_origin={o}", [] if o == "REAL" else ["data_origin must be REAL or SAMPLE."]
    ck.run("CP0-11", "Data origin declared", INFO, origin, fail_status=WARNING, required=False)

    rep.validated_output_hashes = {str(scope_path): sha256_file(scope_path)}
    return rep


# ---------------------------------------------------------------------------
# CP1 — Tool registry
# ---------------------------------------------------------------------------
TOOL_STATUSES = {"INSTALLED", "AVAILABLE_NOT_INSTALLED", "UNAVAILABLE", "DEPRECATED", "NOT_VERIFIED",
                 "DECLARED_AVAILABLE", "DECLARED_UNAVAILABLE"}
OPERATIONAL = {"INSTALLED", "DECLARED_AVAILABLE"}


def validate_cp1(registry_xlsx: Path, registry_json: Path, research_mode: str) -> ValidationReport:
    rep = ValidationReport("CP1")
    ck = Checker(rep)
    check_outputs_exist(ck, [registry_xlsx, registry_json])
    if not registry_json.exists():
        return rep
    data = json.loads(registry_json.read_text())
    tools, caps = data["tools"], data["capabilities"]

    def xlsx_matches_json():
        from openpyxl import load_workbook
        wb = load_workbook(registry_xlsx, read_only=True)
        ws = wb["Tool_Registry"]
        ids = [r[0] for r in ws.iter_rows(min_row=2, values_only=True) if r and r[0]]
        want = [t["tool_id"] for t in tools]
        return ids == want, f"{len(ids)} rows in workbook", [] if ids == want else [
            "Tool_Registry.xlsx does not match the registry data; re-run CP1."]
    ck.run("CP1-01", "Workbook matches registry data", CRITICAL, xlsx_matches_json)

    def fields():
        issues = []
        for t in tools:
            for f_ in ("tool_id", "name", "category", "status", "verification_method", "verified_at", "license"):
                if _blank(t.get(f_)):
                    issues.append(f"{t.get('tool_id')} {t.get('name')}: missing '{f_}'.")
            if t.get("status") not in TOOL_STATUSES:
                issues.append(f"{t.get('tool_id')}: unknown status {t.get('status')}.")
        return not issues, f"{len(tools)} tools checked", issues
    ck.run("CP1-02", "Every tool has status, licence and verification method", MAJOR, fields)

    def licences():
        unknown = [t for t in tools if t.get("license_risk") == "UNKNOWN"]
        copyleft = [t for t in tools if t.get("license_risk") == "COPYLEFT"]
        issues = [f"{t['tool_id']} {t['name']}: licence unknown — confirm before use." for t in unknown]
        issues += [f"{t['tool_id']} {t['name']}: copyleft licence ({t['license']}) — check with legal before redistribution."
                   for t in copyleft]
        return not issues, f"{len(unknown)} unknown, {len(copyleft)} copyleft", issues
    ck.run("CP1-03", "Licences identified", MINOR, licences, fail_status=WARNING, required=False)

    def no_auto_install():
        bad = [t for t in tools if t.get("installed_by_tool")]
        return not bad, "no packages were installed by the tool", [
            f"{t['name']} was installed automatically; this is not allowed." for t in bad]
    ck.run("CP1-04", "No automatic installation of packages", CRITICAL, no_auto_install)

    def core_stack():
        missing = [c for c in caps if c["required_for_core"] and not c["operational"]]
        return not missing, "core stack operational" if not missing else "core capability missing", [
            f"Core capability '{c['capability']}' not operational. Needs one of: {c['candidate_tools']}." for c in missing]
    ck.run("CP1-05", "Core build stack operational (Python, Excel, Word, conversion)", CRITICAL, core_stack)

    def research_caps():
        needed = [c for c in caps if c["required_for_research"]]
        missing = [c for c in needed if not c["operational"]]
        if not missing:
            return True, "research capabilities operational", []
        if research_mode == "manual_documents":
            return True, (f"{len(missing)} research capabilities unavailable; accepted because research_mode="
                          "manual_documents (sources supplied by user into data/sources)"), []
        return False, f"{len(missing)} research capabilities unavailable", [
            f"Research capability '{c['capability']}' unavailable ({c['note']}). Either ask your admin to enable it, "
            f"or set research_mode: manual_documents in config/project.yaml and supply source files in data/sources/."
            for c in missing]
    ck.run("CP1-06", "Research capabilities operational for chosen research mode", CRITICAL, research_caps)

    def limitations_documented():
        undocumented = [t for t in tools if t["status"] not in OPERATIONAL and _blank(t.get("limitations"))]
        return not undocumented, "limitations documented for every non-operational tool", [
            f"{t['tool_id']} {t['name']}: explain the limitation." for t in undocumented]
    ck.run("CP1-07", "Limitations documented", MAJOR, limitations_documented)

    def probe_freshness():
        failed = [p for p in data.get("probe_log", []) if p["result"] == "ERROR"]
        msg = f"{len(data.get('probe_log', []))} probes, {len(failed)} errored (recorded, not hidden)"
        return True, msg, []
    ck.run("CP1-08", "Probe failures recorded", INFO, probe_freshness, required=False)

    rep.validated_output_hashes = {str(p): sha256_file(p) for p in (registry_xlsx, registry_json) if p.exists()}
    return rep
