"""Persistent checkpoint state (SQLite).

Every checkpoint has exactly one current record plus an append-only event log
(the audit trail) and an append-only run history (one row per producer run,
with a snapshot of every output file so approved evidence is never lost).
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

NOT_STARTED = "NOT_STARTED"
IN_PROGRESS = "IN_PROGRESS"
BLOCKED = "BLOCKED"
APPROVED = "APPROVED"
STATUSES = (NOT_STARTED, IN_PROGRESS, BLOCKED, APPROVED)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def hash_files(paths: list[str | Path]) -> dict[str, str]:
    """Hash each existing file. Missing files are recorded as 'MISSING'."""
    out = {}
    for p in paths:
        p = Path(p)
        out[str(p)] = sha256_file(p) if p.exists() else "MISSING"
    return out


@dataclass
class CheckpointRecord:
    checkpoint_id: str
    status: str = NOT_STARTED
    created_at: str = field(default_factory=now_iso)
    modified_at: str = field(default_factory=now_iso)
    input_hashes: dict = field(default_factory=dict)
    output_hashes: dict = field(default_factory=dict)
    validation: dict = field(default_factory=dict)      # latest ValidationReport.to_dict()
    feedback: list = field(default_factory=list)        # [{ts, user, text}]
    approval: dict | None = None                        # {ts, user, output_hashes, run_id}
    approval_history: list = field(default_factory=list)
    versions: dict = field(default_factory=dict)        # tool/model/package versions
    revalidation_reason: str | None = None
    current_run_id: int | None = None

    def to_row(self) -> tuple:
        return (
            self.checkpoint_id, self.status, self.created_at, self.modified_at,
            json.dumps(self.input_hashes), json.dumps(self.output_hashes),
            json.dumps(self.validation), json.dumps(self.feedback),
            json.dumps(self.approval), json.dumps(self.approval_history),
            json.dumps(self.versions), self.revalidation_reason, self.current_run_id,
        )

    @classmethod
    def from_row(cls, r: sqlite3.Row) -> "CheckpointRecord":
        return cls(
            checkpoint_id=r["checkpoint_id"], status=r["status"],
            created_at=r["created_at"], modified_at=r["modified_at"],
            input_hashes=json.loads(r["input_hashes"]),
            output_hashes=json.loads(r["output_hashes"]),
            validation=json.loads(r["validation"]),
            feedback=json.loads(r["feedback"]),
            approval=json.loads(r["approval"]),
            approval_history=json.loads(r["approval_history"]),
            versions=json.loads(r["versions"]),
            revalidation_reason=r["revalidation_reason"],
            current_run_id=r["current_run_id"],
        )


SCHEMA = """
CREATE TABLE IF NOT EXISTS checkpoints (
    checkpoint_id TEXT PRIMARY KEY,
    status TEXT NOT NULL CHECK (status IN ('NOT_STARTED','IN_PROGRESS','BLOCKED','APPROVED')),
    created_at TEXT NOT NULL,
    modified_at TEXT NOT NULL,
    input_hashes TEXT NOT NULL,
    output_hashes TEXT NOT NULL,
    validation TEXT NOT NULL,
    feedback TEXT NOT NULL,
    approval TEXT,
    approval_history TEXT NOT NULL,
    versions TEXT NOT NULL,
    revalidation_reason TEXT,
    current_run_id INTEGER
);
CREATE TABLE IF NOT EXISTS events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts TEXT NOT NULL,
    checkpoint_id TEXT NOT NULL,
    action TEXT NOT NULL,
    actor TEXT NOT NULL,
    from_status TEXT,
    to_status TEXT,
    detail TEXT
);
CREATE TABLE IF NOT EXISTS runs (
    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    checkpoint_id TEXT NOT NULL,
    ts TEXT NOT NULL,
    snapshot_dir TEXT NOT NULL,
    output_hashes TEXT NOT NULL,
    input_hashes TEXT NOT NULL
);
CREATE TRIGGER IF NOT EXISTS events_no_update BEFORE UPDATE ON events
BEGIN SELECT RAISE(ABORT, 'audit log is append-only'); END;
CREATE TRIGGER IF NOT EXISTS events_no_delete BEFORE DELETE ON events
BEGIN SELECT RAISE(ABORT, 'audit log is append-only'); END;
"""


class StateStore:
    def __init__(self, db_path: str | Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.executescript(SCHEMA)

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    # ---- checkpoint records -------------------------------------------------
    def ensure(self, checkpoint_ids: list[str]) -> None:
        with self._conn() as c:
            for cp in checkpoint_ids:
                if not c.execute("SELECT 1 FROM checkpoints WHERE checkpoint_id=?", (cp,)).fetchone():
                    c.execute("INSERT INTO checkpoints VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                              CheckpointRecord(cp).to_row())

    def get(self, cp: str) -> CheckpointRecord:
        with self._conn() as c:
            r = c.execute("SELECT * FROM checkpoints WHERE checkpoint_id=?", (cp,)).fetchone()
        if r is None:
            raise KeyError(cp)
        return CheckpointRecord.from_row(r)

    def save(self, rec: CheckpointRecord) -> None:
        if rec.status not in STATUSES:
            raise ValueError(f"invalid status {rec.status}")
        rec.modified_at = now_iso()
        with self._conn() as c:
            c.execute("INSERT OR REPLACE INTO checkpoints VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", rec.to_row())

    # ---- audit log ----------------------------------------------------------
    def log(self, cp: str, action: str, actor: str, from_status: str | None = None,
            to_status: str | None = None, detail: Any = None) -> None:
        with self._conn() as c:
            c.execute(
                "INSERT INTO events (ts, checkpoint_id, action, actor, from_status, to_status, detail) "
                "VALUES (?,?,?,?,?,?,?)",
                (now_iso(), cp, action, actor, from_status, to_status,
                 json.dumps(detail, default=str) if detail is not None else None))

    def events(self, cp: str | None = None) -> list[dict]:
        with self._conn() as c:
            if cp:
                rows = c.execute("SELECT * FROM events WHERE checkpoint_id=? ORDER BY event_id", (cp,)).fetchall()
            else:
                rows = c.execute("SELECT * FROM events ORDER BY event_id").fetchall()
        return [dict(r) for r in rows]

    # ---- run history ----------------------------------------------------------
    def add_run(self, cp: str, snapshot_dir: str, output_hashes: dict, input_hashes: dict) -> int:
        with self._conn() as c:
            cur = c.execute(
                "INSERT INTO runs (checkpoint_id, ts, snapshot_dir, output_hashes, input_hashes) VALUES (?,?,?,?,?)",
                (cp, now_iso(), snapshot_dir, json.dumps(output_hashes), json.dumps(input_hashes)))
            return int(cur.lastrowid)

    def runs(self, cp: str) -> list[dict]:
        with self._conn() as c:
            rows = c.execute("SELECT * FROM runs WHERE checkpoint_id=? ORDER BY run_id", (cp,)).fetchall()
        return [dict(r) | {"output_hashes": json.loads(r["output_hashes"]),
                           "input_hashes": json.loads(r["input_hashes"])} for r in rows]
