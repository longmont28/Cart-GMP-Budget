"""Research evidence registry with stable IDs.

ID prefixes: SRC (source), CLAIM (research claim), COST (cost item),
ASSUMP (assumption), ISSUE (audit issue). IDs are never reused; records are
never deleted, only superseded (status=SUPERSEDED) so history is preserved.

Every record carries `data_origin` (REAL / SAMPLE / MOCK) so sample or test
evidence can never be mistaken for real research.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from .state import now_iso

PREFIXES = {"sources": "SRC", "claims": "CLAIM", "cost_items": "COST",
            "assumptions": "ASSUMP", "issues": "ISSUE"}
ORIGINS = {"REAL", "SAMPLE", "MOCK"}


class EvidenceRegistry:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            self.data = json.loads(self.path.read_text())
        else:
            self.data = {k: [] for k in PREFIXES} | {"counters": {k: 0 for k in PREFIXES}}
            self._save()

    def _save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, indent=2, ensure_ascii=False))
        tmp.replace(self.path)

    def _next_id(self, kind: str) -> str:
        self.data["counters"][kind] += 1
        return f"{PREFIXES[kind]}-{self.data['counters'][kind]:04d}"

    def all(self, kind: str, include_superseded: bool = False) -> list[dict]:
        rows = self.data[kind]
        return rows if include_superseded else [r for r in rows if r.get("status") != "SUPERSEDED"]

    def find(self, kind: str, **match: Any) -> dict | None:
        for r in self.all(kind):
            if all(r.get(k) == v for k, v in match.items()):
                return r
        return None

    def add(self, kind: str, record: dict, origin: str, created_by: str) -> dict:
        if origin not in ORIGINS:
            raise ValueError(f"data_origin must be one of {ORIGINS}")
        rec = dict(record)
        rec.update(id=self._next_id(kind), data_origin=origin, created_by=created_by,
                   created_at=now_iso(), status=rec.get("status", "ACTIVE"))
        self.data[kind].append(rec)
        self._save()
        return rec

    def upsert_by_key(self, kind: str, key: str, record: dict, origin: str, created_by: str) -> dict:
        """Keep the ID stable for the same logical key. If the content changed,
        supersede the old record and issue a new ID (never edit silently)."""
        existing = self.find(kind, key=key)
        payload = dict(record) | {"key": key}
        if existing:
            same = all(existing.get(k) == v for k, v in payload.items())
            if same and existing["data_origin"] == origin:
                return existing
            existing["status"] = "SUPERSEDED"
            existing["superseded_at"] = now_iso()
            new = self.add(kind, payload | {"supersedes": existing["id"]}, origin, created_by)
            existing["superseded_by"] = new["id"]
            self._save()
            return new
        return self.add(kind, payload, origin, created_by)

    def record_source_access(self, url: str, title: str, ok: bool, detail: str, origin: str,
                             created_by: str) -> dict:
        """Record a source access attempt. Failures are recorded, never papered over."""
        return self.add("sources", {"url": url, "title": title,
                                    "access_status": "ACCESSED" if ok else "ACCESS_FAILED",
                                    "access_detail": detail, "accessed_at": now_iso()},
                        origin, created_by)
