"""CP5 Financial model — planned for a later build stage.

Build the formula-driven Excel model (executive budget, development, CAPEX, stages, materials, labour, facilities, QA/RA, outsourcing, failure/rework, 3 scenarios, sensitivity, evidence register).
"""


def run(*args, **kwargs):
    raise NotImplementedError("CP5 Financial model is not implemented in this build stage (CP0-CP1 only).")
