"""CP3 Regulatory map — planned for a later build stage.

Map each process stage to applicable regulatory requirements with citations to the regulation/guidance actually retrieved; never invent requirements.
"""


def run(*args, **kwargs):
    raise NotImplementedError("CP3 Regulatory map is not implemented in this build stage (CP0-CP1 only).")
