"""CP6-CP8 independent audits — planned for a later build stage.

Completeness, evidence & arithmetic, and commercial-reality audits run as an independent agent that writes ISSUE-xxxx records; it can never approve a checkpoint.
"""


def run(*args, **kwargs):
    raise NotImplementedError("CP6-CP8 independent audits is not implemented in this build stage (CP0-CP1 only).")
