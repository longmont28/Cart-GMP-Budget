"""CP4 BOM and supplier price evidence — planned for a later build stage.

Build the BOM; for the 20 largest cost drivers seek 3 independent price references; record pack size, purchase vs consumed quantity, currency, date, grade, URL, confidence; unknown prices = QUOTATION_REQUIRED.
"""


def run(*args, **kwargs):
    raise NotImplementedError("CP4 BOM and supplier price evidence is not implemented in this build stage (CP0-CP1 only).")
