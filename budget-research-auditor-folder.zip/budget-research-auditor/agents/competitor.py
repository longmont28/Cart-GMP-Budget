"""CP2 Competitor Intelligence — planned for a later build stage.

Identify >=5 comparable competitors, extract manufacturing/R&D/CAPEX evidence from primary documents, separate product cost from price and company-wide spend; every claim gets SRC/CLAIM IDs or a MISSING_EVIDENCE label.
"""


def run(*args, **kwargs):
    raise NotImplementedError("CP2 Competitor Intelligence is not implemented in this build stage (CP0-CP1 only).")
