"""CP0 producer: turn config/project.yaml into Project_Scope.json + assumptions register."""
from __future__ import annotations

import json

from checkpoints.evidence import EvidenceRegistry

ASSUMPTION_FIELDS = ("description", "value", "unit", "basis", "confidence", "owner",
                     "exposure_low", "exposure_high")


def build_scope(ws, ev: EvidenceRegistry) -> dict:
    cfg = ws.load_project()
    origin = cfg.get("data_origin", "REAL")
    register = []
    for a in cfg.get("assumptions", []) or []:
        rec = ev.upsert_by_key("assumptions", a["key"], {f: a.get(f) for f in ASSUMPTION_FIELDS}
                               | {"source_checkpoint": "CP0", "resolution": "OPEN"},
                               origin=origin if origin in ("REAL", "SAMPLE") else "SAMPLE",
                               created_by="agents.scope")
        register.append({"assumption_id": rec["id"], "key": a["key"],
                         **{f: a.get(f) for f in ASSUMPTION_FIELDS}, "status": "OPEN",
                         "data_origin": rec["data_origin"]})

    scope = {
        "document": "Project_Scope", "generated_by": "agents.scope",  # run time lives in checkpoint state, so identical input -> identical file
        "data_origin": origin,
        "project": cfg.get("project", {}),
        "product": cfg.get("product", {}),
        "geography": cfg.get("geography", {}),
        "development_stage": cfg.get("development_stage"),
        "annual_production_volume": cfg.get("annual_production_volume", {}),
        "project_duration_months": cfg.get("project_duration_months"),
        "currency": cfg.get("currency", {}),
        "facility": cfg.get("facility", {}),
        "budget_boundaries": cfg.get("budget_boundaries", {}),
        "research_mode": cfg.get("research_mode"),
        "scenarios": cfg.get("scenarios", {}),
        "assumptions_register": register,
    }
    out = ws.cp_dir("CP0") / "Project_Scope.json"
    out.write_text(json.dumps(scope, indent=2, ensure_ascii=False))
    return scope
