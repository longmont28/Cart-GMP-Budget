"""CP3 Technical process map — planned for a later build stage.

Reconstruct lifecycle and manufacturing stages (inputs, equipment, labour, outputs, QC) from patents, publications and manuals; assign a cost category and evidence/assumption to every stage.
"""


def run(*args, **kwargs):
    raise NotImplementedError("CP3 Technical process map is not implemented in this build stage (CP0-CP1 only).")
