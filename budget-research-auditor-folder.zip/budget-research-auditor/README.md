# Budget Research Auditor

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/longmont28/Cart-GMP-Budget/blob/main/budget-research-auditor/notebooks/Budget_Research_Auditor.ipynb)

A checkpoint-gated research tool for building a defensible development and
manufacturing budget for a new product. It is **not** a one-shot report
generator: each step (CP0 → CP9) produces a deliverable, validates it with
automated tests, and then **waits for a person to approve it**. Nothing
downstream can start until everything upstream is approved.

> **Build stage:** CP0 (Project Scope) and CP1 (Research Tools) are fully
> implemented, together with the gate engine, state store, audit log,
> invalidation, CLI and dashboard. CP2–CP9 are defined in the workflow but
> not built yet; running them returns a clear "not implemented" refusal.

## Install

```bash
cd budget-research-auditor
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest -q          # 33 tests, all MOCK data in temp folders
```

## Run in Google Colab (no installation, no code editing)

1. Click **Open in Colab** above.
2. Run **Step 1** (prepares everything; stores the project in your Google
   Drive so progress survives between sessions).
3. Run **Step 2**: a control panel opens. It always shows the next checkpoint
   that is not approved yet. For each checkpoint: **① Run → ② Review →
   ③ tick "I have reviewed" and Approve**, or write feedback and click
   **Request revision**. Project settings are edited in the panel's
   *Project settings* tab.

Note: the `host_tool` entries in `config/tools.yaml` describe what was
available to the Claude session that built the tool (web search disabled by
the admin, Microsoft 365 connected). Update them for your own environment
before running CP1.

## Use it (junior-analyst walkthrough)

1. **Describe the project** in `config/project.yaml` (product, country,
   stage, yearly volume, duration, currency, facility, what is in and out of
   the budget, key assumptions). The shipped file is a **SAMPLE** project; it
   is flagged as such on every screen and in every file.
2. **Start the dashboard**: `streamlit run app/dashboard.py`
   (or use the CLI: `python -m app.cli status`).
3. **Run CP0.** The tool writes `outputs/CP0/Project_Scope.json`, gives every
   assumption an ID (`ASSUMP-0001` …) and runs 12 checks.
4. **Review** the file, then either **Approve** (type your name and the
   exact phrase `APPROVE CP0`) or **Request revision** with feedback.
5. **Run CP1.** The tool checks which research tools exist, their licences
   and limits, and writes `outputs/CP1/Tool_Registry.xlsx`. Approve or revise.
6. Repeat for each checkpoint. Export the audit trail at any time.

### CLI reference

```bash
python -m app.cli status              # all checkpoints, detects changed files
python -m app.cli run CP0             # produce + validate
python -m app.cli show CP0            # details, issues, exposure, history
python -m app.cli review CP0          # list / open deliverables
python -m app.cli validate CP0        # re-run validation
python -m app.cli approve CP0         # interactive only (terminal), asks name + phrase
python -m app.cli revise CP0 "Volume should be 20 doses"
python -m app.cli export-log          # audit_logs/audit_log_<time>.json + .md
```

## Gate rules (enforced in `checkpoints/manager.py`, shared by CLI and dashboard)

| Rule | How it is enforced |
|---|---|
| Four states only | SQLite `CHECK` constraint: NOT_STARTED, IN_PROGRESS, BLOCKED, APPROVED |
| Failed validation blocks | Any failed CRITICAL/MAJOR test, or a required test that did not execute, sets BLOCKED with actionable issues |
| Untested ≠ passed | A test that crashes is recorded NOT_EXECUTED and blocks; an empty report never passes |
| Human approval only | Named approver required; agent identities (`claude`, `agent`, `ai`, …) rejected; exact phrase `APPROVE <CP>` required; CLI approval only from an interactive terminal |
| Approval covers exact files | Approval is refused if deliverables changed after validation |
| No skipping | Upstream must be APPROVED; there is no skip or bulk-approve command |
| Change propagation | Edited inputs or deliverables (detected by SHA-256) revoke that approval and flag every downstream checkpoint for revalidation |
| Nothing silently overwritten | Every run is snapshotted to `data/checkpoint_state/archive/<CP>/run_NNNN_<time>/` |
| Tamper-evident log | `events` table is append-only (database triggers block UPDATE/DELETE) |

Honest limitation: the approval check is a process control, not
authentication. Anyone with shell access to the project folder could call the
Python API directly. For stronger control, keep the project folder under
version control and review the exported audit log.

## Evidence system

`data/evidence/registry.json` holds sources (`SRC-`), claims (`CLAIM-`),
cost items (`COST-`), assumptions (`ASSUMP-`) and audit issues (`ISSUE-`).
IDs are never reused. A changed record is superseded, not edited, so history
is kept. Every record carries `data_origin` = `REAL`, `SAMPLE` or `MOCK`.
Failed source access is recorded as `ACCESS_FAILED`, never filled in.

## Project layout

```text
config/project.yaml      project scope input (SAMPLE shipped)
config/tools.yaml        CP1 tool catalogue and capability map
app/dashboard.py         Streamlit dashboard        app/cli.py  CLI
checkpoints/manager.py   gates, approval, invalidation, audit export
checkpoints/state.py     SQLite state, runs, append-only events
checkpoints/validators.py validation framework + CP0/CP1 validators
checkpoints/evidence.py  ID-based evidence registry
agents/scope.py          CP0 producer
agents/infrastructure.py CP1 producer (probes; never installs)
agents/*.py, models/*.py, reports/docx_builder.py   later stages (stubs)
reports/excel_builder.py shared workbook formatting
data/checkpoint_state/   state.sqlite + archived run snapshots
outputs/<CP>/            current deliverables       audit_logs/  exports
```

## Environment notes (from the build session, 16 Oct 2026)

* Python 3.13, pandas, openpyxl, python-docx, MarkItDown installed; Streamlit
  and pytest installed for the interface and tests.
* PyPI and npm registries reachable; GitHub API access not enabled for the
  session; Claude web search disabled by the organisation admin. CP1 records
  these as limitations. With `research_mode: web`, CP1 will therefore BLOCK
  until web research is enabled, or you switch to
  `research_mode: manual_documents` and supply sources in `data/sources/`.
* Set `BRA_OFFLINE=1` to skip all network probes (tools become NOT_VERIFIED,
  never guessed).
