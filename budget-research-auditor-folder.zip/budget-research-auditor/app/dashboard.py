"""Streamlit checkpoint dashboard.

Run:  streamlit run app/dashboard.py

All gate logic lives in checkpoints.manager; this page only calls it, so the
rules are identical in the CLI and the dashboard. There is no "skip" control.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

CODE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE_ROOT))
ROOT = Path(os.environ.get("BRA_ROOT", CODE_ROOT))   # project workspace (override for tests)

from checkpoints.manager import DEFS, ORDER, CheckpointManager, GateError  # noqa: E402

st.set_page_config(page_title="Budget Research Auditor", layout="wide")
m = CheckpointManager(ROOT)
flagged = m.refresh(actor="dashboard")

st.title("Budget Research Auditor")
st.caption("Checkpoint-gated budget research. Each step must be validated and approved by you before the next can start.")
if flagged:
    st.warning(f"Changes detected since last run — flagged for revalidation: {', '.join(flagged)}")

scope_path = ROOT / "outputs" / "CP0" / "Project_Scope.json"
if scope_path.exists() and json.loads(scope_path.read_text()).get("data_origin") == "SAMPLE":
    st.error("SAMPLE PROJECT — all values are illustrative. Replace config/project.yaml with your real project.")

ov = pd.DataFrame(m.overview())
st.subheader("Progress")
st.dataframe(ov[["checkpoint", "title", "status", "validation_passed", "approved_by", "approved_at",
                 "needs_revalidation", "implemented"]], hide_index=True, use_container_width=True)

cp = st.selectbox("Checkpoint", ORDER, format_func=lambda c: f"{c} — {DEFS[c].title}")
rec = m.get(cp)
gate = m.gate_problems(cp)

c1, c2, c3 = st.columns(3)
c1.metric("Status", rec.status)
v = rec.validation or {}
c2.metric("Validation", "—" if not v.get("tests") else ("PASSED" if v.get("passed") else "FAILED"))
exp = m.exposure(cp)
if exp:
    c3.metric("Exposure from open assumptions",
              f"{exp['exposure_low']:,.0f} to {exp['exposure_high']:,.0f} {exp['currency']}",
              help=exp["basis"])
if rec.revalidation_reason:
    st.warning(f"Needs revalidation: {rec.revalidation_reason}")
if gate:
    st.info("Cannot start yet: " + " ".join(gate))
if not DEFS[cp].producer:
    st.info(f"{cp} is not built yet in this version of the tool.")

# ---- deliverables -----------------------------------------------------------
st.subheader("Deliverables")
for p in m.deliverable_paths(cp):
    if p.exists():
        st.download_button(f"Download {p.name}", p.read_bytes(), file_name=p.name, key=f"dl-{p}")
        st.caption(str(p))
    else:
        st.write(f"✗ {p.name} (not generated)")
with st.expander("Review deliverables inline"):
    for p in m.deliverable_paths(cp):
        if not p.exists():
            continue
        if p.suffix == ".json":
            st.json(json.loads(p.read_text()), expanded=False)
        elif p.suffix == ".xlsx":
            for name, df in pd.read_excel(p, sheet_name=None).items():
                st.markdown(f"**{p.name} › {name}**")
                st.dataframe(df, hide_index=True, use_container_width=True)
        elif p.suffix == ".md":
            st.markdown(p.read_text())
    m.store.log(cp, "DELIVERABLES_VIEWED", "dashboard-user")

# ---- validation -------------------------------------------------------------
st.subheader("Validation results")
if v.get("tests"):
    st.caption(f"Ran {v['ran_at']} — {v['summary']}")
    st.dataframe(pd.DataFrame(v["tests"])[["test_id", "name", "status", "severity", "blocking", "message"]],
                 hide_index=True, use_container_width=True)
    if v.get("blocking_issues"):
        st.error("Critical issues (must be fixed):\n\n" + "\n".join(f"- {i}" for i in v["blocking_issues"]))
    gaps = [i for t in v["tests"] if t["status"] == "WARNING" for i in t["issues"]]
    if gaps:
        st.warning("Warnings / evidence gaps:\n\n" + "\n".join(f"- {i}" for i in gaps))
else:
    st.write("Not validated yet.")

if scope_path.exists() and cp == "CP0":
    st.subheader("Assumptions register")
    st.dataframe(pd.DataFrame(json.loads(scope_path.read_text())["assumptions_register"]),
                 hide_index=True, use_container_width=True)

# ---- actions ----------------------------------------------------------------
st.subheader("Actions")
a1, a2 = st.columns(2)
with a1:
    if st.button("Run checkpoint", disabled=bool(gate) or not DEFS[cp].producer):
        try:
            m.run(cp, actor="dashboard-run")
            st.rerun()
        except (GateError, NotImplementedError, Exception) as exc:
            st.error(str(exc))
    if st.button("Re-run validation", disabled=rec.status == "NOT_STARTED" or not DEFS[cp].validator):
        try:
            m.validate(cp, actor="dashboard-validate")
            st.rerun()
        except (GateError, NotImplementedError) as exc:
            st.error(str(exc))
    if st.button("Export audit log"):
        j, md = m.export_audit_log(actor="dashboard-user")
        st.success(f"Written: {j.name}, {md.name}")
        st.download_button("Download audit log (Markdown)", md.read_bytes(), file_name=md.name)

with a2:
    with st.form(f"approve-{cp}"):
        st.markdown("**Approve checkpoint** — you confirm you have reviewed the deliverables.")
        name = st.text_input("Your full name")
        phrase = st.text_input(f"Type APPROVE {cp}")
        note = st.text_input("Note (optional)")
        if st.form_submit_button("Approve"):
            try:
                m.approve(cp, name, phrase, note)
                st.success(f"{cp} approved.")
                st.rerun()
            except GateError as exc:
                st.error(str(exc))
    with st.form(f"revise-{cp}"):
        st.markdown("**Request revision**")
        rname = st.text_input("Your name", key=f"rn-{cp}")
        fb = st.text_area("What should change?")
        if st.form_submit_button("Request revision"):
            try:
                m.request_revision(cp, rname or "unknown-user", fb)
                st.success("Returned to IN_PROGRESS.")
                st.rerun()
            except GateError as exc:
                st.error(str(exc))

# ---- history ----------------------------------------------------------------
st.subheader("Approval history and feedback")
st.write(rec.approval_history or "No approvals yet.")
st.write(rec.feedback or "No feedback yet.")
with st.expander("Event log for this checkpoint"):
    st.dataframe(pd.DataFrame(m.store.events(cp)), hide_index=True, use_container_width=True)
with st.expander("Previous runs (archived snapshots)"):
    st.dataframe(pd.DataFrame(m.store.runs(cp)), hide_index=True, use_container_width=True)
