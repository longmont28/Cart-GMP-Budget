"""Command-line interface (fallback when Streamlit is not available).

    python -m app.cli status
    python -m app.cli show CP0
    python -m app.cli run CP0
    python -m app.cli validate CP0
    python -m app.cli review CP0
    python -m app.cli approve CP0            # interactive: asks for your name and the phrase
    python -m app.cli revise CP0 "feedback"
    python -m app.cli refresh
    python -m app.cli export-log

There is deliberately no command that skips or bulk-approves checkpoints.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import shutil
import sys
from pathlib import Path

from checkpoints.manager import DEFS, ORDER, CheckpointManager, GateError

ROOT = Path(__file__).resolve().parents[1]


def _print_cp(m: CheckpointManager, cp: str) -> None:
    r = m.get(cp)
    print(f"\n=== {cp} — {DEFS[cp].title} ===")
    print(f"Status:             {r.status}")
    if r.revalidation_reason:
        print(f"Needs revalidation: {r.revalidation_reason}")
    print("Deliverables:")
    for p in m.deliverable_paths(cp):
        print(f"  {'✓' if p.exists() else '✗'} {p}")
    v = r.validation or {}
    if v.get("tests"):
        print(f"Validation ({v['ran_at']}): {'PASSED' if v['passed'] else 'FAILED'}  {v['summary']}")
        for t in v["tests"]:
            flag = " [BLOCKING]" if t["blocking"] else ""
            print(f"  {t['status']:<12} {t['severity']:<8} {t['test_id']} {t['name']}: {t['message']}{flag}")
        if v.get("blocking_issues"):
            print("Critical issues (must fix):")
            for i in v["blocking_issues"]:
                print(f"  - {i}")
        warn = [i for t in v["tests"] if t["status"] == "WARNING" for i in t["issues"]]
        if warn:
            print("Warnings / evidence gaps:")
            for i in warn:
                print(f"  - {i}")
    elif v.get("blocking_issues"):
        print("Issues:", *v["blocking_issues"], sep="\n  - ")
    exp = m.exposure(cp)
    if exp:
        print(f"Open assumptions: {exp['open_assumptions']}  exposure range: "
              f"{exp['exposure_low']:,.0f} to {exp['exposure_high']:,.0f} {exp['currency']} ({exp['basis']})")
    if r.feedback:
        print("Feedback:", *[f"{f['ts']} {f['user']}: {f['text']}" for f in r.feedback], sep="\n  ")
    if r.approval_history:
        print("Approval history:")
        for a in r.approval_history:
            print(f"  {a['ts']} by {a['user']}" + (f" — revoked {a['revoked_at']}: {a['revoked_reason']}"
                                                  if a.get("revoked_at") else ""))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="bra", description="Budget Research Auditor — checkpoint CLI")
    ap.add_argument("--root", default=str(ROOT))
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status")
    for c in ("show", "run", "validate", "review", "approve"):
        s = sub.add_parser(c)
        s.add_argument("cp", choices=ORDER)
    s = sub.add_parser("revise")
    s.add_argument("cp", choices=ORDER)
    s.add_argument("feedback")
    s.add_argument("--user", default=None)
    sub.add_parser("refresh")
    sub.add_parser("export-log")
    a = ap.parse_args(argv)
    m = CheckpointManager(a.root)

    try:
        if a.cmd == "status":
            flagged = m.refresh()
            if flagged:
                print(f"Changes detected — flagged for revalidation: {flagged}")
            print(f"{'CP':<4} {'Title':<40} {'Status':<12} {'Validated':<10} {'Approved by':<15} Note")
            for o in m.overview():
                note = ("needs revalidation" if o["needs_revalidation"] else "") or ("" if o["implemented"] else "not built yet")
                print(f"{o['checkpoint']:<4} {o['title']:<40} {o['status']:<12} "
                      f"{str(o['validation_passed']):<10} {str(o['approved_by'] or ''):<15} {note}")
        elif a.cmd == "show":
            _print_cp(m, a.cp)
        elif a.cmd == "run":
            m.refresh()
            m.run(a.cp, actor="cli-run")
            _print_cp(m, a.cp)
            print(f"\n{a.cp} is waiting for YOUR review. Approve with: python -m app.cli approve {a.cp}")
        elif a.cmd == "validate":
            m.refresh()
            m.validate(a.cp, actor="cli-validate")
            _print_cp(m, a.cp)
        elif a.cmd == "review":
            for p in m.deliverable_paths(a.cp):
                print(p)
                if p.exists() and shutil.which("xdg-open"):
                    subprocess.Popen(["xdg-open", str(p)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            m.store.log(a.cp, "DELIVERABLES_REVIEWED", "cli-user")
        elif a.cmd == "approve":
            if not sys.stdin.isatty():
                print("Approval must be given interactively by a person at a terminal.", file=sys.stderr)
                return 2
            m.refresh()
            _print_cp(m, a.cp)
            name = input("\nYour full name: ").strip()
            phrase = input(f"Type 'APPROVE {a.cp}' to approve: ").strip()
            note = input("Optional note: ").strip()
            m.approve(a.cp, name, phrase, note)
            print(f"{a.cp} APPROVED by {name}.")
        elif a.cmd == "revise":
            user = a.user or (input("Your name: ").strip() if sys.stdin.isatty() else "unknown-user")
            m.request_revision(a.cp, user, a.feedback)
            print(f"{a.cp} returned to IN_PROGRESS with your feedback.")
        elif a.cmd == "refresh":
            print("Flagged:", m.refresh() or "nothing changed")
        elif a.cmd == "export-log":
            j, md = m.export_audit_log()
            print(f"Audit log written:\n  {j}\n  {md}")
    except (GateError, NotImplementedError) as exc:
        print(f"REFUSED: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
