"""One-cell control panel for Colab / Jupyter (ipywidgets).

The user never edits code: the panel always works on the NEXT checkpoint that
is not yet approved, and offers buttons for each action. All gate rules are
still enforced by checkpoints.manager (same as CLI and dashboard).

    from app.colab_panel import show
    show(PROJECT)
"""
from __future__ import annotations

import contextlib
import html
import io
import json
from pathlib import Path

import ipywidgets as W
import yaml
from IPython.display import HTML, display

from app.cli import _print_cp
from checkpoints.manager import DEFS, ORDER, CheckpointManager, GateError

STATUS_ZH = {"NOT_STARTED": ("未开始", "#888"), "IN_PROGRESS": ("等待你审批", "#b26b00"),
             "BLOCKED": ("被阻止（需修正）", "#c00000"), "APPROVED": ("已批准", "#1a7f37")}


def _capture(fn, *a, **k) -> str:
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        try:
            fn(*a, **k)
        except (GateError, NotImplementedError) as exc:
            print(f"\n❌ 未执行 (refused): {exc}")
    return buf.getvalue()


class Panel:
    def __init__(self, root: str | Path):
        self.root = Path(root)
        self.m = CheckpointManager(self.root)
        self.status_html = W.HTML()
        self.title = W.HTML()
        self.out = W.Output(layout=W.Layout(border="1px solid #ddd", padding="6px", max_height="520px",
                                            overflow="auto"))
        # action buttons
        self.b_run = W.Button(description="① 运行本节点 Run", button_style="primary", layout=W.Layout(width="200px"))
        self.b_view = W.Button(description="② 查看结果文件 Review", layout=W.Layout(width="200px"))
        self.b_reval = W.Button(description="重新验证 Re-validate", layout=W.Layout(width="200px"))
        self.b_log = W.Button(description="导出审计日志 Audit log", layout=W.Layout(width="200px"))
        # approval
        self.name = W.Text(placeholder="你的姓名 Your name", description="姓名:", layout=W.Layout(width="320px"))
        self.ack = W.Checkbox(value=False, indent=False)
        self.b_approve = W.Button(description="③ 批准 Approve", button_style="success", layout=W.Layout(width="200px"))
        # revision
        self.feedback = W.Textarea(placeholder="需要修改什么？What should change?", layout=W.Layout(width="520px", height="70px"))
        self.b_revise = W.Button(description="要求修改 Request revision", button_style="warning", layout=W.Layout(width="200px"))
        # project settings editor
        self.yaml_box = W.Textarea(layout=W.Layout(width="100%", height="420px"))
        self.b_save = W.Button(description="保存项目设置 Save", button_style="info")
        self.yaml_msg = W.HTML()

        self.b_run.on_click(lambda _: self._act(self._run))
        self.b_view.on_click(lambda _: self._act(self._view))
        self.b_reval.on_click(lambda _: self._act(self._revalidate))
        self.b_log.on_click(lambda _: self._act(self._export))
        self.b_approve.on_click(lambda _: self._act(self._approve))
        self.b_revise.on_click(lambda _: self._act(self._revise))
        self.b_save.on_click(lambda _: self._save_yaml())
        self._load_yaml()
        self.refresh()

    # ------------------------------------------------------------- helpers
    @property
    def cp(self) -> str:
        for cp in ORDER:
            if self.m.get(cp).status != "APPROVED":
                return cp
        return ORDER[-1]

    def refresh(self) -> None:
        flagged = self.m.refresh(actor="colab-panel")
        rows = []
        for o in self.m.overview():
            zh, color = STATUS_ZH[o["status"]]
            extra = " · 需重新验证" if o["needs_revalidation"] else ("" if o["implemented"] else " · 尚未开发")
            mark = "👉 " if o["checkpoint"] == self.cp else ""
            rows.append(f"<tr><td>{mark}<b>{o['checkpoint']}</b></td><td>{html.escape(o['title'])}</td>"
                        f"<td style='color:{color};font-weight:600'>{zh}{extra}</td>"
                        f"<td>{html.escape(o['approved_by'] or '')}</td></tr>")
        warn = f"<p style='color:#c00000'>检测到改动，以下节点需重新验证: {', '.join(flagged)}</p>" if flagged else ""
        self.status_html.value = (warn + "<table style='border-collapse:collapse'>"
                                  "<tr><th align=left>节点</th><th align=left>内容</th><th align=left>状态</th>"
                                  "<th align=left>批准人</th></tr>" + "".join(rows) + "</table>")
        cp = self.cp
        rec = self.m.get(cp)
        hint = {
            "NOT_STARTED": "下一步：点 ① 运行本节点。",
            "IN_PROGRESS": "下一步：点 ② 查看结果文件；没问题就勾选并点 ③ 批准，否则写下意见点“要求修改”。"
                           if rec.validation.get("passed") else "已要求修改：改好项目设置后，点 ① 重新运行。",
            "BLOCKED": "检查没通过：看下面的“Critical issues”，修改项目设置后点 ① 重新运行。",
            "APPROVED": "全部节点已批准。",
        }[rec.status]
        if not DEFS[cp].producer:
            hint = f"{cp} 这一步还没有开发完成（目前只开发到 CP1）。"
        self.title.value = f"<h3 style='margin:4px 0'>当前节点 Current: {cp} — {html.escape(DEFS[cp].title)}</h3><p>{hint}</p>"
        self.ack.description = f"我已审阅 {cp} 的结果文件，确认批准"
        self.ack.value = False

    def _act(self, fn) -> None:
        self.out.clear_output()
        with self.out:
            fn()
        self.refresh()

    # ------------------------------------------------------------- actions
    def _run(self):
        cp = self.cp
        print(_capture(self.m.run, cp, "colab-panel"))
        print(_capture(_print_cp, self.m, cp))

    def _revalidate(self):
        print(_capture(self.m.validate, self.cp, "colab-panel"))
        print(_capture(_print_cp, self.m, self.cp))

    def _view(self):
        import pandas as pd
        cp = self.cp
        print(_capture(_print_cp, self.m, cp))
        for p in self.m.deliverable_paths(cp):
            if not p.exists():
                continue
            display(HTML(f"<h4>📄 {p.name}</h4>"))
            if p.suffix == ".json":
                print(json.dumps(json.loads(p.read_text()), indent=2, ensure_ascii=False))
            elif p.suffix == ".xlsx":
                for name, df in pd.read_excel(p, sheet_name=None).items():
                    display(HTML(f"<b>Sheet: {html.escape(name)}</b>"))
                    display(df)
            elif p.suffix == ".md":
                print(p.read_text())
            try:
                from google.colab import files
                files.download(str(p))
            except Exception:
                pass
        self.m.store.log(cp, "DELIVERABLES_REVIEWED", self.name.value or "colab-user")

    def _approve(self):
        cp = self.cp
        if not self.ack.value:
            print("请先勾选“我已审阅……确认批准”，再点 ③ 批准。")
            return
        try:
            self.m.approve(cp, self.name.value.strip(), f"APPROVE {cp}", note="approved in Colab panel")
            print(f"✅ {cp} 已由 {self.name.value.strip()} 批准。可以继续下一个节点。")
        except GateError as exc:
            print(f"❌ 未批准: {exc}")

    def _revise(self):
        print(_capture(self.m.request_revision, self.cp, self.name.value.strip() or "colab-user",
                       self.feedback.value))
        print("已记录修改意见。改好“项目设置”后，点 ① 重新运行。")
        self.feedback.value = ""

    def _export(self):
        j, md = self.m.export_audit_log(actor=self.name.value or "colab-user")
        print(md.read_text())
        try:
            from google.colab import files
            files.download(str(md))
        except Exception:
            pass

    # ---------------------------------------------------------- yaml editor
    def _load_yaml(self):
        self.yaml_box.value = (self.root / "config" / "project.yaml").read_text()

    def _save_yaml(self):
        try:
            data = yaml.safe_load(self.yaml_box.value)
            if not isinstance(data, dict):
                raise ValueError("内容不是有效的设置")
        except Exception as exc:
            self.yaml_msg.value = f"<span style='color:#c00000'>❌ 格式错误，未保存: {html.escape(str(exc))}</span>"
            return
        (self.root / "config" / "project.yaml").write_text(self.yaml_box.value)
        self.yaml_msg.value = ("<span style='color:#1a7f37'>✅ 已保存。如果 CP0 之前已批准，它会被标记为需重新验证；"
                               "请回到上面点 ① 重新运行 CP0。</span>")
        self.refresh()

    # --------------------------------------------------------------- layout
    def widget(self):
        approve_box = W.VBox([W.HTML("<b>批准 Approve</b>"), self.name, self.ack, self.b_approve])
        revise_box = W.VBox([W.HTML("<b>或者：要求修改 Request revision</b>"), self.feedback, self.b_revise])
        main = W.VBox([
            self.status_html, self.title,
            W.HBox([self.b_run, self.b_view, self.b_reval, self.b_log]),
            self.out,
            W.HBox([approve_box, W.HTML("&nbsp;" * 6), revise_box]),
        ])
        settings = W.VBox([
            W.HTML("<p>这里是项目设置（CP0 的输入）。直接在框里修改，然后点保存。"
                   "把 <code>data_origin: SAMPLE</code> 改成 <code>REAL</code> 表示真实项目；"
                   "没有网络检索工具时把 <code>research_mode</code> 设为 <code>manual_documents</code>。</p>"),
            self.yaml_box, W.HBox([self.b_save, self.yaml_msg])])
        tabs = W.Tab(children=[main, settings])
        tabs.set_title(0, "流程 Workflow")
        tabs.set_title(1, "项目设置 Project settings")
        return tabs


def show(root: str | Path) -> Panel:
    p = Panel(root)
    display(p.widget())
    return p
