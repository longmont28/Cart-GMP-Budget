"""CP1 producer: probe every candidate research tool and write Tool_Registry.xlsx.

Nothing is installed or executed from third-party packages: Python packages are
checked with importlib.metadata (no import), registries are queried for
metadata only, and the suggested install command is written down for a human
to review. Every probe — including failures — is logged in the workbook.

Set BRA_OFFLINE=1 to skip all network probes (they are then recorded as
skipped, and the affected tools become NOT_VERIFIED rather than guessed).
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from importlib import metadata

import requests
import yaml

from checkpoints.evidence import EvidenceRegistry
from checkpoints.state import now_iso
from reports.excel_builder import build_workbook

OPERATIONAL = {"INSTALLED", "DECLARED_AVAILABLE"}
TIMEOUT = 10


def classify_license(lic: str | None) -> str:
    if not lic:
        return "UNKNOWN"
    l = lic.upper()
    if l.startswith("UNKNOWN"):
        return "UNKNOWN"
    if re.search(r"\b(A?GPL|LGPL|MPL|EUPL|SSPL)", l):
        return "COPYLEFT"
    if re.search(r"(MIT|APACHE|BSD|PSF|ISC|PYTHON SOFTWARE|UNLICENSE|ZLIB)", l):
        return "PERMISSIVE"
    return "UNKNOWN"


class Prober:
    def __init__(self, offline: bool | None = None):
        self.offline = (os.environ.get("BRA_OFFLINE") == "1") if offline is None else offline
        self.log: list[dict] = []

    def _record(self, tool: str, probe: str, target: str, result: str, detail: str) -> None:
        self.log.append({"ts": now_iso(), "tool": tool, "probe": probe, "target": target,
                         "result": result, "detail": detail[:500]})

    def local_dist(self, tool: str, dist: str) -> tuple[str | None, str | None]:
        """Return (installed version, licence from local package metadata)."""
        try:
            md = metadata.metadata(dist)
            v = md["Version"]
            lic = md.get("License-Expression") or ""
            if not lic or len(lic) > 60:
                cls = [c.split("::")[-1].strip() for c in (md.get_all("Classifier") or []) if c.startswith("License ::")]
                raw = md.get("License") or ""
                lic = "; ".join(cls) or (raw if raw and len(raw) <= 60 else "")
            self._record(tool, "importlib.metadata", dist, "OK", f"installed {v}; licence {lic or 'not stated'}")
            return v, lic or None
        except metadata.PackageNotFoundError:
            self._record(tool, "importlib.metadata", dist, "NOT_FOUND", "not installed")
            return None, None

    def pypi(self, tool: str, dist: str) -> dict | None:
        url = f"https://pypi.org/pypi/{dist}/json"
        if self.offline:
            self._record(tool, "pypi", url, "SKIPPED", "offline mode")
            return None
        try:
            r = requests.get(url, timeout=TIMEOUT)
            if r.status_code != 200:
                self._record(tool, "pypi", url, "ERROR", f"HTTP {r.status_code}")
                return None
            info = r.json()["info"]
            lic = info.get("license_expression") or info.get("license") or ""
            if not lic or len(lic) > 60:
                cls = [c.split("::")[-1].strip() for c in info.get("classifiers", []) if c.startswith("License ::")]
                lic = "; ".join(cls) or (lic[:60] if lic else "")
            out = {"latest": info.get("version"), "license": lic, "home": info.get("home_page") or
                   (info.get("project_urls") or {}).get("Homepage")}
            self._record(tool, "pypi", url, "OK", json.dumps(out))
            return out
        except Exception as exc:
            self._record(tool, "pypi", url, "ERROR", repr(exc))
            return None

    def npm(self, tool: str, name: str) -> dict | None:
        url = f"https://registry.npmjs.org/{name}/latest"
        if self.offline:
            self._record(tool, "npm", url, "SKIPPED", "offline mode")
            return None
        try:
            r = requests.get(url, timeout=TIMEOUT)
            if r.status_code != 200:
                self._record(tool, "npm", url, "ERROR", f"HTTP {r.status_code}")
                return None
            d = r.json()
            out = {"latest": d.get("version"), "license": d.get("license"), "deprecated": d.get("deprecated")}
            self._record(tool, "npm", url, "OK", json.dumps(out))
            return out
        except Exception as exc:
            self._record(tool, "npm", url, "ERROR", repr(exc))
            return None

    def github(self, tool: str, repo: str) -> dict | None:
        target = f"gh api repos/{repo}"
        if self.offline:
            self._record(tool, "github", target, "SKIPPED", "offline mode")
            return None
        if not shutil.which("gh"):
            self._record(tool, "github", target, "ERROR", "gh CLI not installed")
            return None
        try:
            p = subprocess.run(["gh", "api", f"repos/{repo}"], capture_output=True, text=True, timeout=20)
            if p.returncode != 0:
                self._record(tool, "github", target, "ERROR", (p.stderr or p.stdout).strip())
                return None
            d = json.loads(p.stdout)
            out = {"license": (d.get("license") or {}).get("spdx_id"), "archived": d.get("archived"),
                   "pushed_at": d.get("pushed_at"), "stars": d.get("stargazers_count")}
            self._record(tool, "github", target, "OK", json.dumps(out))
            return out
        except Exception as exc:
            self._record(tool, "github", target, "ERROR", repr(exc))
            return None

    def cli(self, tool: str, cmd: str) -> str | None:
        path = shutil.which(cmd)
        if not path:
            self._record(tool, "which", cmd, "NOT_FOUND", "not on PATH")
            return None
        try:
            p = subprocess.run([cmd, "--version"], capture_output=True, text=True, timeout=15)
            v = (p.stdout or p.stderr).strip().splitlines()[0] if (p.stdout or p.stderr) else "unknown"
        except Exception as exc:
            v = f"found at {path}; --version failed: {exc!r}"
        self._record(tool, "which/--version", cmd, "OK", v)
        return v

    def egress(self, url: str) -> bool:
        if self.offline:
            self._record("network", "HEAD", url, "SKIPPED", "offline mode")
            return False
        try:
            r = requests.head(url, timeout=TIMEOUT, allow_redirects=True)
            self._record("network", "HEAD", url, "OK" if r.status_code < 400 else "ERROR", f"HTTP {r.status_code}")
            return r.status_code < 400
        except Exception as exc:
            self._record("network", "HEAD", url, "ERROR", repr(exc))
            return False


def probe_tool(t: dict, pr: Prober) -> dict:
    name, kind = t["name"], t["kind"]
    row = {"name": name, "category": t.get("category"), "purpose": t.get("purpose"), "kind": kind,
           "installed_version": None, "latest_version": None, "license": t.get("license_hint"),
           "license_source": "catalogue hint" if t.get("license_hint") else None,
           "status": None, "verification_method": None, "verified_at": now_iso(),
           "limitations": t.get("limitations_hint", ""), "permissions": "", "install_command": "",
           "installed_by_tool": False, "source_repo": t.get("github")}
    lim = [row["limitations"]] if row["limitations"] else []

    if kind == "python_package":
        dist = t["dist"]
        row["installed_version"], local_lic = pr.local_dist(name, dist)
        if local_lic:
            row["license"], row["license_source"] = local_lic, "installed package metadata"
        meta = pr.pypi(name, dist)
        row["verification_method"] = "importlib.metadata + PyPI JSON API"
        if meta:
            row["latest_version"], row["license"], row["license_source"] = meta["latest"], meta["license"], "PyPI metadata"
        if row["installed_version"]:
            row["status"] = "INSTALLED"
            row["permissions"] = "Runs locally inside this tool's Python process"
        elif meta:
            row["status"] = "AVAILABLE_NOT_INSTALLED"
            row["install_command"] = f"pip install {dist}=={meta['latest']}  # review before running; not executed"
            lim.append("Not installed; requires human review and manual installation")
        else:
            row["status"] = "NOT_VERIFIED"
            lim.append("Not installed and registry metadata could not be retrieved")
        if t.get("github"):
            gh = pr.github(name, t["github"])
            if gh and gh.get("archived"):
                lim.append("Repository is archived")

    elif kind == "npm_package":
        meta = pr.npm(name, t["npm"])
        row["verification_method"] = "npm registry metadata"
        if meta:
            row["latest_version"], row["license"], row["license_source"] = meta["latest"], meta["license"], "npm metadata"
            if meta.get("deprecated"):
                row["status"] = "DEPRECATED"
                lim.append(f"Deprecated on npm: {meta['deprecated']}")
            else:
                row["status"] = "AVAILABLE_NOT_INSTALLED"
                row["install_command"] = f"npx -y {t['npm']}  # review before running; not executed"
        else:
            row["status"] = "NOT_VERIFIED"
            lim.append("npm registry metadata could not be retrieved")

    elif kind == "github_repo":
        gh = pr.github(name, t["github"])
        row["verification_method"] = "GitHub API via gh CLI"
        if gh:
            row["license"], row["license_source"] = gh.get("license"), "GitHub API"
            row["status"] = "UNAVAILABLE" if gh.get("archived") else "AVAILABLE_NOT_INSTALLED"
            row["latest_version"] = f"last push {gh.get('pushed_at')}"
        else:
            row["status"] = "NOT_VERIFIED"
            lim.append("Repository could not be checked from this environment (see Probe_Log)")

    elif kind == "cli":
        v = pr.cli(name, t["command"])
        row["verification_method"] = "PATH lookup + --version"
        row["installed_version"] = v
        row["status"] = "INSTALLED" if v else "UNAVAILABLE"
        row["permissions"] = "Local executable" if v else ""
        if not v:
            lim.append("Not on PATH")
        if t.get("command") == "gh" and v:
            lim.append("Installed, but repository access depends on the session's GitHub permissions")

    elif kind == "host_tool":
        row["status"] = t.get("declared_status", "NOT_VERIFIED")
        row["verification_method"] = f"Declared by operator ({t.get('declared_by', 'unknown')}) — not verifiable from Python"
        row["license"], row["license_source"] = "Proprietary service (host-provided)", "catalogue"
        row["permissions"] = "Governed by the Claude workspace / organisation admin settings"
        if t.get("declared_note"):
            lim.append(t["declared_note"])
    else:
        row["status"] = "NOT_VERIFIED"
        row["verification_method"] = f"unknown kind {kind}"
        lim.append("Unknown tool kind in catalogue")

    if not row["license"]:
        row["license"], row["license_source"] = "UNKNOWN - not determinable here", "see Probe_Log"
        row["license_risk"] = "UNKNOWN"
    elif kind == "host_tool":
        row["license_risk"] = "N/A (service)"
    else:
        row["license_risk"] = classify_license(row["license"])
    row["limitations"] = "; ".join(x for x in lim if x)
    return row


def build_tool_registry(ws, ev: EvidenceRegistry, prober: Prober | None = None) -> dict:
    cat = yaml.safe_load(ws.tools_yaml.read_text())
    pr = prober or Prober()
    tools = []
    for i, t in enumerate(cat["tools"], start=1):
        row = probe_tool(t, pr)
        tools.append({"tool_id": f"TOOL-{i:03d}", **row})

    by_name = {t["name"]: t for t in tools}
    caps = []
    for c in cat["capabilities"]:
        statuses = {n: by_name[n]["status"] for n in c["tools"] if n in by_name}
        op = [n for n, s in statuses.items() if s in OPERATIONAL]
        caps.append({"capability": c["capability"], "candidate_tools": list(c["tools"]),
                     "tool_status": statuses, "operational_via": op, "operational": bool(op),
                     "required_for_core": bool(c.get("core")), "required_for_research": bool(c.get("research")),
                     "note": "OK" if op else "; ".join(f"{n}: {s}" for n, s in statuses.items())})

    egress = [{"host": h, "reachable": pr.egress(h)} for h in cat.get("egress_probe_hosts", [])]

    limitations = [{"tool_id": t["tool_id"], "name": t["name"], "status": t["status"], "limitation": t["limitations"]}
                   for t in tools if t["limitations"]]
    for c in caps:
        if not c["operational"]:
            limitations.append({"tool_id": "-", "name": f"capability: {c['capability']}", "status": "NOT OPERATIONAL",
                                "limitation": c["note"]})

    data = {"generated_at": now_iso(), "offline_mode": pr.offline, "tools": tools,
            "capabilities": caps, "egress": egress, "probe_log": pr.log}
    out = ws.cp_dir("CP1")
    (out / "Tool_Registry.json").write_text(json.dumps(data, indent=2, ensure_ascii=False))

    cols = ["tool_id", "name", "category", "purpose", "status", "installed_version", "latest_version",
            "license", "license_risk", "license_source", "verification_method", "verified_at",
            "limitations", "permissions", "install_command", "installed_by_tool", "source_repo"]
    readme = [
        "CP1 Tool Registry — which research tools are usable, under what licence, with what limits.",
        f"Generated {data['generated_at']}. Offline mode: {pr.offline}.",
        "Status meanings: INSTALLED = present and usable; AVAILABLE_NOT_INSTALLED = exists, needs human-reviewed install;",
        "DECLARED_AVAILABLE / DECLARED_UNAVAILABLE = host capability stated by the operator (Python cannot check it);",
        "NOT_VERIFIED = could not be checked; DEPRECATED / UNAVAILABLE = do not rely on it.",
        "The tool never installs packages. Suggested install commands are for human review only.",
        "Every probe, including failures, is listed on the Probe_Log sheet.",
    ]
    cap_rows = [c | {"candidate_tools": ", ".join(c["candidate_tools"]),
                     "operational_via": ", ".join(c["operational_via"]),
                     "tool_status": "; ".join(f"{k}={v}" for k, v in c["tool_status"].items())} for c in caps]
    build_workbook(out / "Tool_Registry.xlsx", readme, {
        "Tool_Registry": (tools, cols),
        "Capability_Coverage": (cap_rows, None),
        "Limitations": (limitations, None),
        "Network_Egress": (egress, None),
        "Probe_Log": (pr.log, None),
    })
    return data
