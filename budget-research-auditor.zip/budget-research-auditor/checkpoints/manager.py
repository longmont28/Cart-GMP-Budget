"""Checkpoint manager: the only component allowed to change checkpoint status.

Gate rules enforced here (not in the UI, so no front end can bypass them):
1. A checkpoint can only be run when every upstream checkpoint is APPROVED
   and none of them is flagged for revalidation.
2. Failed validation leaves a checkpoint BLOCKED with actionable issues.
3. Approval needs a named human approver, the exact confirmation phrase
   "APPROVE <CP-ID>", a passing validation that covers the current files,
   and approved upstream checkpoints. Agent identities are rejected.
4. When an approved checkpoint's outputs or inputs change, its approval is
   revoked (kept in history) and every downstream checkpoint is flagged for
   revalidation.
5. Every run snapshots its outputs into data/checkpoint_state/archive so
   previously approved files are never silently overwritten.
"""
from __future__ import annotations

import json
import platform
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timezone
from importlib import metadata
from pathlib import Path
from typing import Callable

import yaml

from . import validators as V
from .evidence import EvidenceRegistry
from .state import (APPROVED, BLOCKED, IN_PROGRESS, NOT_STARTED, CheckpointRecord, StateStore,
                    hash_files, now_iso)

TOOL_VERSION = "0.1.0"
AGENT_IDENTITIES = {"agent", "ai", "claude", "assistant", "system", "bot", "auditor", "llm", "automation"}


class GateError(RuntimeError):
    """Raised when an action would bypass a checkpoint gate."""


@dataclass
class Workspace:
    root: Path

    def __post_init__(self):
        self.root = Path(self.root).resolve()

    @property
    def config(self) -> Path: return self.root / "config"
    @property
    def project_yaml(self) -> Path: return self.config / "project.yaml"
    @property
    def tools_yaml(self) -> Path: return self.config / "tools.yaml"
    @property
    def outputs(self) -> Path: return self.root / "outputs"
    @property
    def state_dir(self) -> Path: return self.root / "data" / "checkpoint_state"
    @property
    def archive(self) -> Path: return self.state_dir / "archive"
    @property
    def evidence_path(self) -> Path: return self.root / "data" / "evidence" / "registry.json"
    @property
    def sources_dir(self) -> Path: return self.root / "data" / "sources"
    @property
    def audit_logs(self) -> Path: return self.root / "audit_logs"

    def cp_dir(self, cp: str) -> Path:
        d = self.outputs / cp
        d.mkdir(parents=True, exist_ok=True)
        return d

    def load_project(self) -> dict:
        return yaml.safe_load(self.project_yaml.read_text())


@dataclass
class CheckpointDef:
    cp_id: str
    title: str
    deliverables: list[str]                       # file names inside outputs/<CP>/
    extra_inputs: Callable[[Workspace], list[Path]] = lambda ws: []
    producer: Callable[[Workspace, EvidenceRegistry], None] | None = None
    validator: Callable[[Workspace], V.ValidationReport] | None = None
    supporting: list[str] = field(default_factory=list)   # extra files produced (not gate deliverables)


def _cp0_validator(ws: Workspace) -> V.ValidationReport:
    return V.validate_cp0(ws.outputs / "CP0" / "Project_Scope.json")


def _cp1_validator(ws: Workspace) -> V.ValidationReport:
    mode = json.loads((ws.outputs / "CP0" / "Project_Scope.json").read_text()).get("research_mode", "web")
    return V.validate_cp1(ws.outputs / "CP1" / "Tool_Registry.xlsx",
                          ws.outputs / "CP1" / "Tool_Registry.json", mode)


def _producer(module: str, func: str):
    def call(ws, ev):
        import importlib
        return getattr(importlib.import_module(module), func)(ws, ev)
    return call


CHECKPOINTS: list[CheckpointDef] = [
    CheckpointDef("CP0", "Project Scope", ["Project_Scope.json"],
                  extra_inputs=lambda ws: [ws.project_yaml],
                  producer=_producer("agents.scope", "build_scope"), validator=_cp0_validator),
    CheckpointDef("CP1", "Research Tools & Sources", ["Tool_Registry.xlsx"],
                  extra_inputs=lambda ws: [ws.tools_yaml],
                  producer=_producer("agents.infrastructure", "build_tool_registry"),
                  validator=_cp1_validator, supporting=["Tool_Registry.json"]),
    CheckpointDef("CP2", "Competitor Intelligence", ["Competitor_Benchmark.xlsx"]),
    CheckpointDef("CP3", "Technical Process & Regulatory Map", ["Process_and_Regulatory_Map.xlsx"]),
    CheckpointDef("CP4", "Materials & Supplier Evidence", ["BOM_and_Price_Evidence.xlsx"]),
    CheckpointDef("CP5", "Financial Model", ["Financial_Model.xlsx"]),
    CheckpointDef("CP6", "Audit Round 1: Completeness", ["Completeness_Audit.md"]),
    CheckpointDef("CP7", "Audit Round 2: Evidence & Arithmetic", ["Evidence_Arithmetic_Audit.md"]),
    CheckpointDef("CP8", "Audit Round 3: Commercial Reality", ["Commercial_Reality_Audit.md"]),
    CheckpointDef("CP9", "DOCX Report & Final Approval", ["Final_Report.docx"]),
]
ORDER = [c.cp_id for c in CHECKPOINTS]
DEFS = {c.cp_id: c for c in CHECKPOINTS}


def _versions() -> dict:
    pk = {}
    for p in ("pandas", "openpyxl", "python-docx", "PyYAML", "streamlit", "markitdown", "docling"):
        try:
            pk[p] = metadata.version(p)
        except metadata.PackageNotFoundError:
            pk[p] = None
    return {"budget_research_auditor": TOOL_VERSION, "python": platform.python_version(),
            "packages": pk, "model": "recorded by operator (see config/project.yaml: run_metadata)"}


class CheckpointManager:
    def __init__(self, root: str | Path):
        self.ws = Workspace(Path(root))
        self.store = StateStore(self.ws.state_dir / "state.sqlite")
        self.store.ensure(ORDER)
        self.evidence = EvidenceRegistry(self.ws.evidence_path)

    # ------------------------------------------------------------------ paths
    def deliverable_paths(self, cp: str) -> list[Path]:
        d = DEFS[cp]
        return [self.ws.outputs / cp / f for f in d.deliverables + d.supporting]

    def input_paths(self, cp: str) -> list[Path]:
        idx = ORDER.index(cp)
        upstream = self.deliverable_paths(ORDER[idx - 1]) if idx > 0 else []
        return DEFS[cp].extra_inputs(self.ws) + upstream

    def upstream(self, cp: str) -> list[str]:
        return ORDER[:ORDER.index(cp)]

    def downstream(self, cp: str) -> list[str]:
        return ORDER[ORDER.index(cp) + 1:]

    def get(self, cp: str) -> CheckpointRecord:
        return self.store.get(cp)

    # ------------------------------------------------------------------ gates
    def gate_problems(self, cp: str) -> list[str]:
        problems = []
        for up in self.upstream(cp):
            r = self.store.get(up)
            if r.status != APPROVED:
                problems.append(f"{up} is {r.status}; it must be APPROVED by the user first.")
            elif r.revalidation_reason:
                problems.append(f"{up} needs revalidation: {r.revalidation_reason}")
        return problems

    def _set_status(self, rec: CheckpointRecord, new: str, actor: str, action: str, detail=None):
        old = rec.status
        rec.status = new
        self.store.save(rec)
        self.store.log(rec.checkpoint_id, action, actor, old, new, detail)

    # ------------------------------------------------------- change detection
    def refresh(self, actor: str = "system") -> list[str]:
        """Detect changed inputs/outputs since the last run and flag affected checkpoints."""
        flagged = []
        for cp in ORDER:
            rec = self.store.get(cp)
            if rec.status == NOT_STARTED or not rec.input_hashes:
                continue
            reasons = []
            cur_in = hash_files(self.input_paths(cp))
            changed_in = [p for p, h in cur_in.items() if rec.input_hashes.get(p) != h]
            if changed_in:
                reasons.append(f"inputs changed: {[Path(p).name for p in changed_in]}")
            cur_out = hash_files(self.deliverable_paths(cp))
            changed_out = [p for p, h in cur_out.items() if rec.output_hashes.get(p) != h]
            if changed_out:
                reasons.append(f"deliverables edited outside the tool: {[Path(p).name for p in changed_out]}")
            if reasons and rec.revalidation_reason is None:
                reason = "; ".join(reasons)
                self._revoke(rec, reason, actor)
                flagged.append(cp)
                flagged += self.invalidate_downstream(cp, f"{cp} {reason}", actor)
        return flagged

    def _revoke(self, rec: CheckpointRecord, reason: str, actor: str) -> None:
        if rec.approval:
            rec.approval_history.append(rec.approval | {"revoked_at": now_iso(), "revoked_reason": reason})
            rec.approval = None
        rec.revalidation_reason = reason
        rec.validation = {}
        self._set_status(rec, BLOCKED, actor, "REVALIDATION_REQUIRED", {"reason": reason})

    def invalidate_downstream(self, cp: str, reason: str, actor: str = "system") -> list[str]:
        hit = []
        for d in self.downstream(cp):
            rec = self.store.get(d)
            if rec.status == NOT_STARTED:
                continue
            if rec.revalidation_reason is None:
                self._revoke(rec, f"upstream change — {reason}", actor)
                hit.append(d)
        return hit

    # ------------------------------------------------------------------- run
    def run(self, cp: str, actor: str = "agent") -> CheckpointRecord:
        d = DEFS[cp]
        problems = self.gate_problems(cp)
        if problems:
            self.store.log(cp, "RUN_REFUSED", actor, detail={"problems": problems})
            raise GateError(f"{cp} cannot start: " + " ".join(problems))
        if d.producer is None:
            raise NotImplementedError(f"{cp} ({d.title}) is not implemented yet in this build stage.")

        rec = self.store.get(cp)
        prev_out = dict(rec.output_hashes)
        was_approved = rec.status == APPROVED
        self._set_status(rec, IN_PROGRESS, actor, "RUN_STARTED")

        try:
            d.producer(self.ws, self.evidence)
        except Exception as exc:
            rec = self.store.get(cp)
            rec.validation = {"passed": False, "blocking_issues": [f"Producer failed: {exc!r}"], "tests": []}
            self._set_status(rec, BLOCKED, actor, "RUN_FAILED", {"error": repr(exc)})
            raise

        rec = self.store.get(cp)
        rec.input_hashes = hash_files(self.input_paths(cp))
        rec.output_hashes = hash_files(self.deliverable_paths(cp))
        rec.versions = _versions() | {"run_metadata": self.ws.load_project().get("run_metadata", {})}
        snap = self._snapshot(cp)
        run_id = self.store.add_run(cp, str(snap), rec.output_hashes, rec.input_hashes)
        rec.current_run_id = run_id
        rec.revalidation_reason = None
        self.store.save(rec)
        self.store.log(cp, "RUN_COMPLETED", actor, detail={"run_id": run_id, "snapshot": str(snap)})

        if was_approved and prev_out != rec.output_hashes:
            rec.approval_history.append(rec.approval | {"revoked_at": now_iso(),
                                                        "revoked_reason": "re-run changed deliverables"})
            rec.approval = None
            self.store.save(rec)
            self.invalidate_downstream(cp, f"{cp} re-run produced different deliverables", actor)
        elif was_approved:
            # identical outputs: approval stays valid
            self._set_status(rec, APPROVED, actor, "RUN_NO_CHANGE")
            return rec
        return self.validate(cp, actor)

    def _snapshot(self, cp: str) -> Path:
        n = len(self.store.runs(cp)) + 1
        snap = self.ws.archive / cp / f"run_{n:04d}_{datetime.now(timezone.utc):%Y%m%dT%H%M%S%fZ}"
        snap.mkdir(parents=True, exist_ok=False)
        for p in self.deliverable_paths(cp):
            if p.exists():
                shutil.copy2(p, snap / p.name)
        return snap

    # -------------------------------------------------------------- validate
    def validate(self, cp: str, actor: str = "agent") -> CheckpointRecord:
        d = DEFS[cp]
        rec = self.store.get(cp)
        if rec.status == NOT_STARTED:
            raise GateError(f"{cp} has not been run yet.")
        if d.validator is None:
            raise NotImplementedError(f"{cp} validator not implemented yet.")
        current = hash_files(self.deliverable_paths(cp))
        if current != rec.output_hashes:
            raise GateError(f"{cp} deliverables changed since the last run; re-run {cp} so the change "
                            "is snapshotted and downstream checkpoints are flagged.")
        report = d.validator(self.ws)
        rec.validation = report.to_dict()
        new = IN_PROGRESS if report.passed else BLOCKED
        if rec.status == APPROVED and report.passed:
            new = APPROVED
        elif rec.status == APPROVED and not report.passed:
            rec.approval_history.append(rec.approval | {"revoked_at": now_iso(),
                                                        "revoked_reason": "re-validation failed"})
            rec.approval = None
            self.invalidate_downstream(cp, f"{cp} failed re-validation", actor)
        self._set_status(rec, new, actor, "VALIDATED",
                         {"passed": report.passed, "summary": report.summary()})
        return rec

    # --------------------------------------------------------------- approve
    def approve(self, cp: str, approver: str, confirmation: str, note: str = "") -> CheckpointRecord:
        rec = self.store.get(cp)
        reasons = []
        if not approver or approver.strip().lower() in AGENT_IDENTITIES:
            reasons.append("Approval must be given by a named human user, not an agent.")
        if confirmation != f"APPROVE {cp}":
            reasons.append(f"Type the exact confirmation phrase 'APPROVE {cp}'.")
        if rec.status != IN_PROGRESS:
            reasons.append(f"{cp} is {rec.status}; only a validated IN_PROGRESS checkpoint can be approved.")
        if rec.revalidation_reason:
            reasons.append(f"{cp} needs revalidation: {rec.revalidation_reason}")
        if not rec.validation or not rec.validation.get("passed"):
            reasons.append(f"{cp} has no passing validation.")
        elif rec.validation.get("validated_output_hashes") != {
                p: h for p, h in hash_files(self.deliverable_paths(cp)).items()
                if p in rec.validation.get("validated_output_hashes", {})}:
            reasons.append(f"{cp} deliverables changed after validation; re-run validation.")
        reasons += self.gate_problems(cp)
        if reasons:
            self.store.log(cp, "APPROVAL_REFUSED", approver or "?", detail={"reasons": reasons})
            raise GateError(" ".join(reasons))
        rec.approval = {"ts": now_iso(), "user": approver, "note": note, "run_id": rec.current_run_id,
                        "output_hashes": rec.output_hashes,
                        "validation_ran_at": rec.validation.get("ran_at")}
        rec.approval_history.append(dict(rec.approval))
        self._set_status(rec, APPROVED, approver, "APPROVED", {"note": note})
        return rec

    # -------------------------------------------------------------- revision
    def request_revision(self, cp: str, user: str, feedback: str) -> CheckpointRecord:
        if not feedback.strip():
            raise GateError("Revision feedback cannot be empty.")
        rec = self.store.get(cp)
        if rec.status == NOT_STARTED:
            raise GateError(f"{cp} has not been run yet.")
        rec.feedback.append({"ts": now_iso(), "user": user, "text": feedback})
        if rec.approval:
            rec.approval_history.append(rec.approval | {"revoked_at": now_iso(),
                                                        "revoked_reason": "revision requested"})
            rec.approval = None
            self.invalidate_downstream(cp, f"revision requested on {cp}", user)
        rec.validation = {}
        self._set_status(rec, IN_PROGRESS, user, "REVISION_REQUESTED", {"feedback": feedback})
        return rec

    # ----------------------------------------------------------------- views
    def exposure(self, cp: str) -> dict:
        scope_path = self.ws.outputs / "CP0" / "Project_Scope.json"
        if not scope_path.exists():
            return {}
        scope = json.loads(scope_path.read_text())
        rows = [a for a in scope.get("assumptions_register", []) if a.get("status", "OPEN") != "RESOLVED"]
        lo = sum(a.get("exposure_low") or 0 for a in rows)
        hi = sum(a.get("exposure_high") or 0 for a in rows)
        return {"currency": scope.get("currency", {}).get("reporting"), "open_assumptions": len(rows),
                "exposure_low": lo, "exposure_high": hi,
                "basis": "sum of per-assumption exposure ranges in the CP0 assumptions register (not netted)"}

    def overview(self) -> list[dict]:
        rows = []
        for cp in ORDER:
            r = self.store.get(cp)
            rows.append({"checkpoint": cp, "title": DEFS[cp].title, "status": r.status,
                         "needs_revalidation": r.revalidation_reason,
                         "validation_passed": r.validation.get("passed") if r.validation else None,
                         "approved_by": (r.approval or {}).get("user"),
                         "approved_at": (r.approval or {}).get("ts"),
                         "implemented": DEFS[cp].producer is not None,
                         "modified_at": r.modified_at})
        return rows

    def export_audit_log(self, actor: str = "user") -> tuple[Path, Path]:
        self.ws.audit_logs.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        payload = {"exported_at": now_iso(), "tool_version": TOOL_VERSION,
                   "checkpoints": [self.store.get(cp).__dict__ for cp in ORDER],
                   "runs": {cp: self.store.runs(cp) for cp in ORDER},
                   "events": self.store.events(),
                   "issues": self.evidence.all("issues", include_superseded=True)}
        jp = self.ws.audit_logs / f"audit_log_{stamp}.json"
        jp.write_text(json.dumps(payload, indent=2, default=str, ensure_ascii=False))
        lines = [f"# Budget Research Auditor — audit log", f"Exported {payload['exported_at']}", "",
                 "| Checkpoint | Status | Approved by | Approved at | Revalidation |",
                 "|---|---|---|---|---|"]
        for o in self.overview():
            lines.append(f"| {o['checkpoint']} {o['title']} | {o['status']} | {o['approved_by'] or ''} | "
                         f"{o['approved_at'] or ''} | {o['needs_revalidation'] or ''} |")
        lines += ["", "## Events", "", "| # | Time (UTC) | CP | Action | Actor | From → To |", "|---|---|---|---|---|---|"]
        for e in payload["events"]:
            lines.append(f"| {e['event_id']} | {e['ts']} | {e['checkpoint_id']} | {e['action']} | {e['actor']} | "
                         f"{e['from_status'] or ''} → {e['to_status'] or ''} |")
        mp = self.ws.audit_logs / f"audit_log_{stamp}.md"
        mp.write_text("\n".join(lines))
        self.store.log("ALL", "AUDIT_LOG_EXPORTED", actor, detail={"json": str(jp), "md": str(mp)})
        return jp, mp
